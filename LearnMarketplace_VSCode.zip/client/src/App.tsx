import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import NotFound from "@/pages/not-found";
import Landing from "@/pages/Landing";
import Home from "@/pages/Home";
import StudentDashboard from "@/pages/StudentDashboard";
import InstituteDashboard from "@/pages/InstituteDashboard";
import AdminDashboard from "@/pages/AdminDashboard";
import CourseDetails from "@/pages/CourseDetails";
import InstituteProfile from "@/pages/InstituteProfile";
import Comparison from "@/pages/Comparison";

function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  return (
    <Switch>
      {isLoading || !isAuthenticated ? (
        <Route path="/" component={Landing} />
      ) : (
        <>
          <Route path="/" component={Home} />
          <Route path="/dashboard/student" component={StudentDashboard} />
          <Route path="/dashboard/institute" component={InstituteDashboard} />
          <Route path="/dashboard/admin" component={AdminDashboard} />
          <Route path="/courses/:id" component={CourseDetails} />
          <Route path="/institutes/:id" component={InstituteProfile} />
          <Route path="/comparison" component={Comparison} />
        </>
      )}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
