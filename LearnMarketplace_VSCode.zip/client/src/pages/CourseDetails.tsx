import { useState, useEffect } from "react";
import { useRoute } from "wouter";
import { Clock, Users, Star, Heart, BarChart3, BookOpen, Award, CheckCircle, Loader2, ArrowLeft } from "lucide-react";
import Navigation from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Link } from "wouter";

export default function CourseDetails() {
  const [, params] = useRoute("/courses/:id");
  const courseId = params?.id;
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [reviewText, setReviewText] = useState("");
  const [rating, setRating] = useState(0);

  // Fetch course details
  const { data: course, isLoading: courseLoading, error: courseError } = useQuery({
    queryKey: ["/api/courses", courseId],
    enabled: !!courseId,
    retry: false,
  });

  // Fetch course reviews
  const { data: reviews = [], isLoading: reviewsLoading } = useQuery({
    queryKey: ["/api/courses", courseId, "reviews"],
    enabled: !!courseId,
    retry: false,
  });

  // Check if bookmarked
  const { data: bookmarkStatus } = useQuery({
    queryKey: ["/api/bookmarks", courseId, "check"],
    enabled: isAuthenticated && !!courseId,
    retry: false,
  });

  const isBookmarked = bookmarkStatus?.isBookmarked || false;

  // Bookmark mutation
  const bookmarkMutation = useMutation({
    mutationFn: async () => {
      if (isBookmarked) {
        await apiRequest("DELETE", `/api/bookmarks/${courseId}`);
      } else {
        await apiRequest("POST", "/api/bookmarks", { courseId: parseInt(courseId!) });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bookmarks", courseId, "check"] });
      queryClient.invalidateQueries({ queryKey: ["/api/bookmarks"] });
      toast({
        title: isBookmarked ? "Bookmark removed" : "Course bookmarked",
        description: isBookmarked 
          ? "Course removed from your saved list" 
          : "Course added to your saved list",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update bookmark",
        variant: "destructive",
      });
    },
  });

  // Apply mutation
  const applyMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/applications", { courseId: parseInt(courseId!) });
    },
    onSuccess: () => {
      toast({
        title: "Application submitted",
        description: "Your application has been submitted successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to submit application",
        variant: "destructive",
      });
    },
  });

  // Review submission mutation
  const reviewMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/reviews", {
        courseId: parseInt(courseId!),
        rating,
        comment: reviewText,
      });
    },
    onSuccess: () => {
      toast({
        title: "Review submitted",
        description: "Thank you for your feedback!",
      });
      setReviewText("");
      setRating(0);
      queryClient.invalidateQueries({ queryKey: ["/api/courses", courseId, "reviews"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to submit review",
        variant: "destructive",
      });
    },
  });

  const handleBookmark = () => {
    if (!isAuthenticated) {
      toast({
        title: "Login required",
        description: "Please login to bookmark courses",
        variant: "destructive",
      });
      return;
    }
    bookmarkMutation.mutate();
  };

  const handleApply = () => {
    if (!isAuthenticated) {
      toast({
        title: "Login required",
        description: "Please login to apply for courses",
        variant: "destructive",
      });
      return;
    }
    applyMutation.mutate();
  };

  const handleReviewSubmit = () => {
    if (!isAuthenticated) {
      toast({
        title: "Login required",
        description: "Please login to submit reviews",
        variant: "destructive",
      });
      return;
    }
    if (rating === 0) {
      toast({
        title: "Rating required",
        description: "Please select a rating before submitting",
        variant: "destructive",
      });
      return;
    }
    reviewMutation.mutate();
  };

  const renderStars = (rating: number, interactive = false, onRate?: (rating: number) => void) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-5 h-5 ${interactive ? "cursor-pointer" : ""} ${
          i < Math.floor(rating) 
            ? "text-success-green fill-success-green" 
            : i < rating 
              ? "text-success-green fill-success-green/50" 
              : "text-gray-300"
        }`}
        onClick={interactive && onRate ? () => onRate(i + 1) : undefined}
      />
    ));
  };

  if (courseLoading) {
    return (
      <div className="min-h-screen bg-main-bg">
        <Navigation />
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 animate-spin text-primary-blue" />
          <span className="ml-2 text-gray-600">Loading course details...</span>
        </div>
      </div>
    );
  }

  if (courseError || !course) {
    return (
      <div className="min-h-screen bg-main-bg">
        <Navigation />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <Card>
            <CardContent className="p-8 text-center">
              <h1 className="text-2xl font-bold text-gray-600 mb-4">Course Not Found</h1>
              <p className="text-gray-500 mb-6">The course you're looking for doesn't exist or has been removed.</p>
              <Link href="/">
                <Button className="bg-primary-blue hover:bg-blue-600 text-white">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Courses
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const averageRating = reviews.length > 0 
    ? reviews.reduce((sum: number, review: any) => sum + review.rating, 0) / reviews.length 
    : 0;

  return (
    <div className="min-h-screen bg-main-bg">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back Button */}
        <div className="mb-6">
          <Link href="/">
            <Button variant="outline" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Courses
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Course Header */}
            <Card>
              <CardContent className="p-8">
                <div className="flex flex-col md:flex-row gap-6">
                  <img
                    src={course.thumbnail || "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"}
                    alt={`${course.title} thumbnail`}
                    className="w-full md:w-64 h-48 object-cover rounded-lg"
                  />
                  
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <Badge className="bg-primary-blue text-white mb-2">
                          {course.institute?.name || "Institute"}
                        </Badge>
                        <h1 className="text-3xl font-bold text-text-primary mb-2">
                          {course.title}
                        </h1>
                        <p className="text-gray-600 mb-4">{course.shortDescription}</p>
                      </div>
                    </div>

                    {/* Rating */}
                    <div className="flex items-center mb-4">
                      <div className="flex mr-2">
                        {renderStars(averageRating)}
                      </div>
                      <span className="text-sm text-gray-600">
                        {averageRating.toFixed(1)} ({reviews.length} reviews)
                      </span>
                    </div>

                    {/* Course Meta */}
                    <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                      <span className="flex items-center">
                        <Clock className="w-4 h-4 mr-1" />
                        {course.duration}
                      </span>
                      <span className="flex items-center">
                        {course.courseType === "online" ? <BookOpen className="w-4 h-4 mr-1" /> : <Users className="w-4 h-4 mr-1" />}
                        <span className="capitalize">{course.courseType}</span>
                      </span>
                      <span className="flex items-center">
                        <Award className="w-4 h-4 mr-1" />
                        Certificate Included
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Course Description */}
            <Card>
              <CardHeader>
                <CardTitle>About This Course</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 leading-relaxed mb-6">
                  {course.description}
                </p>

                {/* Prerequisites */}
                {course.prerequisites && course.prerequisites.length > 0 && (
                  <div className="mb-6">
                    <h3 className="font-semibold text-text-primary mb-3">Prerequisites</h3>
                    <div className="flex flex-wrap gap-2">
                      {course.prerequisites.map((prereq: string, index: number) => (
                        <Badge key={index} variant="outline">
                          {prereq}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Features */}
                {course.features && course.features.length > 0 && (
                  <div>
                    <h3 className="font-semibold text-text-primary mb-3">What You'll Get</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {course.features.map((feature: string, index: number) => (
                        <div key={index} className="flex items-center">
                          <CheckCircle className="w-4 h-4 text-success-green mr-2" />
                          <span className="text-gray-700">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Reviews Section */}
            <Card>
              <CardHeader>
                <CardTitle>Reviews & Ratings</CardTitle>
              </CardHeader>
              <CardContent>
                {/* Add Review Form */}
                {isAuthenticated && (
                  <div className="mb-8 p-4 bg-secondary-bg rounded-lg">
                    <h4 className="font-semibold mb-4">Write a Review</h4>
                    <div className="mb-4">
                      <Label className="block text-sm font-medium mb-2">Rating</Label>
                      <div className="flex">
                        {renderStars(rating, true, setRating)}
                      </div>
                    </div>
                    <Textarea
                      value={reviewText}
                      onChange={(e) => setReviewText(e.target.value)}
                      placeholder="Share your experience with this course..."
                      className="mb-4"
                      rows={4}
                    />
                    <Button
                      onClick={handleReviewSubmit}
                      disabled={reviewMutation.isPending}
                      className="bg-primary-blue hover:bg-blue-600 text-white"
                    >
                      {reviewMutation.isPending ? "Submitting..." : "Submit Review"}
                    </Button>
                  </div>
                )}

                {/* Reviews List */}
                {reviewsLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin text-primary-blue" />
                  </div>
                ) : reviews.length > 0 ? (
                  <div className="space-y-6">
                    {reviews.map((review: any) => (
                      <div key={review.id} className="border-b border-gray-200 pb-6 last:border-b-0">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center">
                            <div className="flex mr-2">
                              {renderStars(review.rating)}
                            </div>
                            <span className="text-sm text-gray-600">
                              {new Date(review.createdAt).toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                        {review.comment && (
                          <p className="text-gray-700">{review.comment}</p>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Star className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-600 mb-2">No reviews yet</h3>
                    <p className="text-gray-500">Be the first to review this course</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Pricing Card */}
            <Card className="sticky top-8">
              <CardContent className="p-6">
                <div className="text-center mb-6">
                  <div className="text-3xl font-bold text-text-primary mb-2">
                    {course.price}
                  </div>
                  <p className="text-gray-600">One-time payment</p>
                </div>

                <div className="space-y-3 mb-6">
                  <Button
                    onClick={handleApply}
                    disabled={applyMutation.isPending}
                    className="w-full bg-accent-orange hover:bg-orange-600 text-white"
                  >
                    {applyMutation.isPending ? "Applying..." : "Apply Now"}
                  </Button>
                  
                  <Button
                    onClick={handleBookmark}
                    disabled={bookmarkMutation.isPending}
                    variant="outline"
                    className="w-full"
                  >
                    <Heart className={`w-4 h-4 mr-2 ${isBookmarked ? "fill-current text-accent-orange" : ""}`} />
                    {isBookmarked ? "Bookmarked" : "Bookmark"}
                  </Button>
                  
                  <Button variant="outline" className="w-full">
                    <BarChart3 className="w-4 h-4 mr-2" />
                    Add to Compare
                  </Button>
                </div>

                <Separator className="my-6" />

                <div className="space-y-4 text-sm">
                  <h4 className="font-semibold">Course Includes:</h4>
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <CheckCircle className="w-4 h-4 text-success-green mr-2" />
                      Lifetime access
                    </div>
                    <div className="flex items-center">
                      <CheckCircle className="w-4 h-4 text-success-green mr-2" />
                      Certificate of completion
                    </div>
                    <div className="flex items-center">
                      <CheckCircle className="w-4 h-4 text-success-green mr-2" />
                      Expert support
                    </div>
                    <div className="flex items-center">
                      <CheckCircle className="w-4 h-4 text-success-green mr-2" />
                      Mobile and desktop access
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Institute Info */}
            {course.institute && (
              <Card>
                <CardHeader>
                  <CardTitle>About the Institute</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center mb-4">
                    <h3 className="font-semibold text-text-primary">
                      {course.institute.name}
                    </h3>
                  </div>
                  <Button variant="outline" className="w-full">
                    View Institute Profile
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
