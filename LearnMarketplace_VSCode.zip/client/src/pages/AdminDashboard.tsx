import { useState, useEffect } from "react";
import { Flag, Users, TrendingUp, Shield, Eye, CheckCircle, XCircle, Loader2 } from "lucide-react";
import Navigation from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";

export default function AdminDashboard() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Redirect non-authenticated users or non-admin users
  useEffect(() => {
    if (!authLoading && (!isAuthenticated || user?.role !== 'admin')) {
      toast({
        title: "Unauthorized",
        description: "Admin access required. Redirecting...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = user ? "/" : "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, user, toast]);

  // Fetch admin metrics
  const { data: metrics, isLoading: metricsLoading } = useQuery({
    queryKey: ["/api/analytics/admin"],
    enabled: isAuthenticated && user?.role === 'admin',
    retry: false,
  });

  // Fetch flagged reviews
  const { data: flaggedReviews = [], isLoading: flaggedLoading } = useQuery({
    queryKey: ["/api/admin/flagged-reviews"],
    enabled: isAuthenticated && user?.role === 'admin',
    retry: false,
  });

  // Update review status mutation
  const updateReviewMutation = useMutation({
    mutationFn: async ({ reviewId, action }: { reviewId: number; action: 'approve' | 'remove' }) => {
      const updates = action === 'approve' 
        ? { isFlagged: false, isApproved: true }
        : { isFlagged: false, isApproved: false };
      
      await apiRequest("PATCH", `/api/reviews/${reviewId}`, updates);
    },
    onSuccess: (_, { action }) => {
      toast({
        title: action === 'approve' ? "Review approved" : "Review removed",
        description: `The review has been ${action === 'approve' ? 'approved' : 'removed'} successfully`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/flagged-reviews"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics/admin"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update review",
        variant: "destructive",
      });
    },
  });

  const handleReviewAction = (reviewId: number, action: 'approve' | 'remove') => {
    updateReviewMutation.mutate({ reviewId, action });
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-main-bg flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary-blue" />
      </div>
    );
  }

  if (!isAuthenticated || user?.role !== 'admin') {
    return null; // Will redirect via useEffect
  }

  return (
    <div className="min-h-screen bg-main-bg">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-text-primary mb-2">
            Admin Panel
          </h1>
          <p className="text-gray-600">
            Monitor and manage platform content and users
          </p>
        </div>

        <Tabs defaultValue="flagged-content" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="flagged-content" className="flex items-center gap-2">
              <Flag className="w-4 h-4" />
              <span className="hidden sm:inline">Flagged Content</span>
            </TabsTrigger>
            <TabsTrigger value="user-management" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              <span className="hidden sm:inline">User Management</span>
            </TabsTrigger>
            <TabsTrigger value="site-metrics" className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              <span className="hidden sm:inline">Site Metrics</span>
            </TabsTrigger>
          </TabsList>

          {/* Flagged Content Tab */}
          <TabsContent value="flagged-content" className="space-y-6">
            {/* Site Overview */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card className="bg-red-50 border border-red-200">
                <CardContent className="p-6 text-center">
                  <div className="text-2xl font-bold text-red-600">
                    {metricsLoading ? <Loader2 className="w-6 h-6 animate-spin mx-auto" /> : (metrics?.flaggedReviews || 0)}
                  </div>
                  <div className="text-sm text-gray-600">Flagged Reviews</div>
                </CardContent>
              </Card>
              
              <Card className="bg-yellow-50 border border-yellow-200">
                <CardContent className="p-6 text-center">
                  <div className="text-2xl font-bold text-yellow-600">
                    {metricsLoading ? <Loader2 className="w-6 h-6 animate-spin mx-auto" /> : (metrics?.pendingDisputes || 0)}
                  </div>
                  <div className="text-sm text-gray-600">Pending Disputes</div>
                </CardContent>
              </Card>
              
              <Card className="bg-green-50 border border-green-200">
                <CardContent className="p-6 text-center">
                  <div className="text-2xl font-bold text-green-600">
                    {metricsLoading ? <Loader2 className="w-6 h-6 animate-spin mx-auto" /> : (metrics?.totalUsers || 0)}
                  </div>
                  <div className="text-sm text-gray-600">Active Users</div>
                </CardContent>
              </Card>
              
              <Card className="bg-blue-50 border border-blue-200">
                <CardContent className="p-6 text-center">
                  <div className="text-2xl font-bold text-blue-600">
                    {metricsLoading ? <Loader2 className="w-6 h-6 animate-spin mx-auto" /> : (metrics?.totalCourses || 0)}
                  </div>
                  <div className="text-sm text-gray-600">Total Courses</div>
                </CardContent>
              </Card>
            </div>

            {/* Flagged Content */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Flagged Content</CardTitle>
              </CardHeader>
              <CardContent>
                {flaggedLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin text-primary-blue" />
                  </div>
                ) : flaggedReviews.length > 0 ? (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Content Type</TableHead>
                          <TableHead>Review Content</TableHead>
                          <TableHead>Reporter</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {flaggedReviews.map((review: any) => (
                          <TableRow key={review.id}>
                            <TableCell>Course Review</TableCell>
                            <TableCell className="max-w-xs truncate">
                              {review.comment || "No comment"}
                            </TableCell>
                            <TableCell>{review.userId}</TableCell>
                            <TableCell>
                              {new Date(review.createdAt).toLocaleDateString()}
                            </TableCell>
                            <TableCell>
                              <div className="flex space-x-2">
                                <Button
                                  size="sm"
                                  className="bg-success-green hover:bg-green-600 text-white"
                                  onClick={() => handleReviewAction(review.id, 'approve')}
                                  disabled={updateReviewMutation.isPending}
                                >
                                  <CheckCircle className="w-4 h-4 mr-1" />
                                  Approve
                                </Button>
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  onClick={() => handleReviewAction(review.id, 'remove')}
                                  disabled={updateReviewMutation.isPending}
                                >
                                  <XCircle className="w-4 h-4 mr-1" />
                                  Remove
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Flag className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-600 mb-2">No flagged content</h3>
                    <p className="text-gray-500">All content appears to be in good standing</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* User Management Tab */}
          <TabsContent value="user-management" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>User Management</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <Users className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-600 mb-2">User management tools</h3>
                  <p className="text-gray-500 mb-4">Advanced user management features would be implemented here</p>
                  <div className="space-y-2">
                    <Button variant="outline" disabled>View All Users</Button>
                    <Button variant="outline" disabled>Manage Institutes</Button>
                    <Button variant="outline" disabled>User Reports</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Site Metrics Tab */}
          <TabsContent value="site-metrics" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Platform Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                {metricsLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin text-primary-blue" />
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h4 className="font-semibold text-lg">Platform Overview</h4>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span>Total Users:</span>
                          <span className="font-semibold">{metrics?.totalUsers || 0}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Total Courses:</span>
                          <span className="font-semibold">{metrics?.totalCourses || 0}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Flagged Reviews:</span>
                          <span className="font-semibold text-red-600">{metrics?.flaggedReviews || 0}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Pending Disputes:</span>
                          <span className="font-semibold text-yellow-600">{metrics?.pendingDisputes || 0}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <h4 className="font-semibold text-lg">Content Health</h4>
                      <div className="space-y-2">
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-success-green h-2 rounded-full" 
                            style={{ 
                              width: `${metrics?.totalCourses > 0 ? ((metrics.totalCourses - (metrics.flaggedReviews || 0)) / metrics.totalCourses) * 100 : 100}%` 
                            }}
                          ></div>
                        </div>
                        <p className="text-sm text-gray-600">
                          Platform health score based on content quality
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Button variant="outline" className="h-20 flex-col">
                    <Shield className="w-6 h-6 mb-2" />
                    Security Report
                  </Button>
                  <Button variant="outline" className="h-20 flex-col">
                    <TrendingUp className="w-6 h-6 mb-2" />
                    Analytics Export
                  </Button>
                  <Button variant="outline" className="h-20 flex-col">
                    <Users className="w-6 h-6 mb-2" />
                    User Activity
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
