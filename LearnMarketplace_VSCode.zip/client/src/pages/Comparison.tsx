import { useState, useEffect } from "react";
import { X, ArrowLeft, CheckCircle, XCircle } from "lucide-react";
import Navigation from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useLocation } from "wouter";
import { Link } from "wouter";
import { ComparisonItem } from "@/lib/types";

export default function Comparison() {
  const [, setLocation] = useLocation();
  const [comparisonItems, setComparisonItems] = useState<ComparisonItem[]>([]);

  // Load comparison items from localStorage or state management
  useEffect(() => {
    const stored = localStorage.getItem('comparisonItems');
    if (stored) {
      try {
        const items = JSON.parse(stored);
        setComparisonItems(items);
      } catch (error) {
        console.error('Failed to parse comparison items:', error);
      }
    }
  }, []);

  // Save to localStorage whenever items change
  useEffect(() => {
    localStorage.setItem('comparisonItems', JSON.stringify(comparisonItems));
  }, [comparisonItems]);

  const removeItem = (id: number) => {
    setComparisonItems(comparisonItems.filter(item => item.id !== id));
  };

  const clearAll = () => {
    setComparisonItems([]);
    setLocation('/');
  };

  if (comparisonItems.length === 0) {
    return (
      <div className="min-h-screen bg-main-bg">
        <Navigation />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <Card>
            <CardContent className="p-8 text-center">
              <h1 className="text-2xl font-bold text-gray-600 mb-4">No Items to Compare</h1>
              <p className="text-gray-500 mb-6">Add courses to your comparison list to see them here.</p>
              <Link href="/">
                <Button className="bg-primary-blue hover:bg-blue-600 text-white">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Browse Courses
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const comparisonFeatures = [
    "Certificate Provided",
    "Live Projects", 
    "Mentor Support",
    "Job Assistance",
    "Mobile Access",
    "Lifetime Access",
    "Community Access",
    "1-on-1 Sessions"
  ];

  return (
    <div className="min-h-screen bg-main-bg">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-text-primary mb-2">
              Course Comparison
            </h1>
            <p className="text-gray-600">
              Compare {comparisonItems.length} course{comparisonItems.length !== 1 ? 's' : ''} side by side
            </p>
          </div>
          <div className="flex gap-3">
            <Link href="/">
              <Button variant="outline">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Courses
              </Button>
            </Link>
            <Button 
              onClick={clearAll}
              variant="outline"
              className="text-red-600 border-red-600 hover:bg-red-50"
            >
              Clear All
            </Button>
          </div>
        </div>

        {/* Comparison Table - Mobile Cards */}
        <div className="block lg:hidden space-y-6">
          {comparisonItems.map((item, index) => (
            <Card key={item.id}>
              <CardHeader className="pb-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-lg mb-2">{item.title}</CardTitle>
                    <Badge variant="outline" className="mb-2">{item.institute}</Badge>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeItem(item.id)}
                    className="text-gray-500 hover:text-red-600"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-600">Price:</span>
                    <div className="font-semibold">{item.price}</div>
                  </div>
                  <div>
                    <span className="text-gray-600">Duration:</span>
                    <div className="font-semibold">{item.duration}</div>
                  </div>
                  <div>
                    <span className="text-gray-600">Rating:</span>
                    <div className="font-semibold">{item.rating ? `${item.rating}/5` : 'N/A'}</div>
                  </div>
                  <div>
                    <span className="text-gray-600">Mode:</span>
                    <div className="font-semibold capitalize">{item.courseType}</div>
                  </div>
                </div>
                
                <div>
                  <span className="text-gray-600 text-sm">Features:</span>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {item.features?.slice(0, 3).map((feature, i) => (
                      <Badge key={i} variant="outline" className="text-xs">
                        {feature}
                      </Badge>
                    ))}
                    {item.features && item.features.length > 3 && (
                      <Badge variant="outline" className="text-xs">
                        +{item.features.length - 3} more
                      </Badge>
                    )}
                  </div>
                </div>

                <div className="pt-2">
                  <Link href={`/courses/${item.id}`}>
                    <Button className="w-full bg-accent-orange hover:bg-orange-600 text-white">
                      View Details
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Comparison Table - Desktop */}
        <div className="hidden lg:block">
          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-48 bg-secondary-bg">Feature</TableHead>
                      {comparisonItems.map((item) => (
                        <TableHead key={item.id} className="min-w-64 text-center bg-secondary-bg">
                          <div className="p-4">
                            <div className="flex items-start justify-between mb-2">
                              <h3 className="font-semibold text-left">{item.title}</h3>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => removeItem(item.id)}
                                className="text-gray-500 hover:text-red-600 ml-2"
                              >
                                <X className="w-4 h-4" />
                              </Button>
                            </div>
                            <Badge variant="outline" className="text-xs">
                              {item.institute}
                            </Badge>
                          </div>
                        </TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {/* Price Row */}
                    <TableRow>
                      <TableCell className="font-medium bg-gray-50">Price</TableCell>
                      {comparisonItems.map((item) => (
                        <TableCell key={item.id} className="text-center">
                          <span className="text-lg font-bold text-text-primary">
                            {item.price}
                          </span>
                        </TableCell>
                      ))}
                    </TableRow>

                    {/* Duration Row */}
                    <TableRow>
                      <TableCell className="font-medium bg-gray-50">Duration</TableCell>
                      {comparisonItems.map((item) => (
                        <TableCell key={item.id} className="text-center">
                          {item.duration}
                        </TableCell>
                      ))}
                    </TableRow>

                    {/* Rating Row */}
                    <TableRow>
                      <TableCell className="font-medium bg-gray-50">Rating</TableCell>
                      {comparisonItems.map((item) => (
                        <TableCell key={item.id} className="text-center">
                          <div className="flex items-center justify-center">
                            <span className="font-semibold">
                              {item.rating ? `${item.rating}/5` : 'N/A'}
                            </span>
                          </div>
                        </TableCell>
                      ))}
                    </TableRow>

                    {/* Course Type Row */}
                    <TableRow>
                      <TableCell className="font-medium bg-gray-50">Mode</TableCell>
                      {comparisonItems.map((item) => (
                        <TableCell key={item.id} className="text-center">
                          <Badge variant="outline" className="capitalize">
                            {item.courseType}
                          </Badge>
                        </TableCell>
                      ))}
                    </TableRow>

                    {/* Features Rows */}
                    {comparisonFeatures.map((feature) => (
                      <TableRow key={feature}>
                        <TableCell className="font-medium bg-gray-50">{feature}</TableCell>
                        {comparisonItems.map((item) => (
                          <TableCell key={item.id} className="text-center">
                            {item.features?.includes(feature) ? (
                              <CheckCircle className="w-5 h-5 text-success-green mx-auto" />
                            ) : (
                              <XCircle className="w-5 h-5 text-gray-300 mx-auto" />
                            )}
                          </TableCell>
                        ))}
                      </TableRow>
                    ))}

                    {/* Action Row */}
                    <TableRow>
                      <TableCell className="font-medium bg-gray-50">Actions</TableCell>
                      {comparisonItems.map((item) => (
                        <TableCell key={item.id} className="text-center p-4">
                          <div className="space-y-2">
                            <Link href={`/courses/${item.id}`}>
                              <Button className="w-full bg-accent-orange hover:bg-orange-600 text-white">
                                View Details
                              </Button>
                            </Link>
                            <Button 
                              variant="outline" 
                              className="w-full"
                              onClick={() => {
                                // Apply functionality would be implemented here
                                alert('Apply functionality would open application form');
                              }}
                            >
                              Apply Now
                            </Button>
                          </div>
                        </TableCell>
                      ))}
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Bottom CTA */}
        <div className="mt-8 text-center">
          <p className="text-gray-600 mb-4">
            Need help choosing? Compare more courses or get personalized recommendations.
          </p>
          <div className="flex justify-center gap-4">
            <Link href="/">
              <Button variant="outline">
                Browse More Courses
              </Button>
            </Link>
            <Button 
              className="bg-primary-blue hover:bg-blue-600 text-white"
              onClick={() => {
                // Contact functionality would be implemented here
                alert('Contact functionality would open contact form');
              }}
            >
              Get Help Choosing
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
