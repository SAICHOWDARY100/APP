import { useState, useEffect } from "react";
import { Plus, BarChart3, Edit, Eye, Users, BookOpen, TrendingUp, Loader2 } from "lucide-react";
import Navigation from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { DashboardStats } from "@/lib/types";

const instituteSchema = z.object({
  name: z.string().min(1, "Institute name is required"),
  description: z.string().min(1, "Description is required"),
  location: z.string().min(1, "Location is required"),
  website: z.string().url("Please enter a valid URL").optional().or(z.literal("")),
  phone: z.string().min(1, "Phone number is required"),
});

const courseSchema = z.object({
  title: z.string().min(1, "Course title is required"),
  description: z.string().min(1, "Description is required"),
  shortDescription: z.string().min(1, "Short description is required"),
  price: z.string().min(1, "Price is required"),
  duration: z.string().min(1, "Duration is required"),
  courseType: z.enum(["online", "offline", "hybrid"]),
  subject: z.string().min(1, "Subject is required"),
  prerequisites: z.string(),
  features: z.string(),
});

export default function InstituteDashboard() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCreateInstituteOpen, setIsCreateInstituteOpen] = useState(false);
  const [isCreateCourseOpen, setIsCreateCourseOpen] = useState(false);

  // Redirect non-authenticated users
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  // Fetch institute profile
  const { data: institute, isLoading: instituteLoading } = useQuery({
    queryKey: ["/api/my-institute"],
    enabled: isAuthenticated,
    retry: false,
  });

  // Fetch institute courses
  const { data: courses = [], isLoading: coursesLoading } = useQuery({
    queryKey: ["/api/institutes", institute?.id, "courses"],
    enabled: !!institute?.id,
    retry: false,
  });

  // Fetch analytics
  const { data: analytics, isLoading: analyticsLoading } = useQuery({
    queryKey: ["/api/analytics/institute", institute?.id],
    enabled: !!institute?.id,
    retry: false,
  });

  // Institute creation form
  const instituteForm = useForm({
    resolver: zodResolver(instituteSchema),
    defaultValues: {
      name: "",
      description: "",
      location: "",
      website: "",
      phone: "",
    },
  });

  // Course creation form
  const courseForm = useForm({
    resolver: zodResolver(courseSchema),
    defaultValues: {
      title: "",
      description: "",
      shortDescription: "",
      price: "",
      duration: "",
      courseType: "online" as const,
      subject: "",
      prerequisites: "",
      features: "",
    },
  });

  // Create institute mutation
  const createInstituteMutation = useMutation({
    mutationFn: async (data: any) => {
      await apiRequest("POST", "/api/institutes", data);
    },
    onSuccess: () => {
      toast({
        title: "Institute created",
        description: "Your institute profile has been created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/my-institute"] });
      setIsCreateInstituteOpen(false);
      instituteForm.reset();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create institute",
        variant: "destructive",
      });
    },
  });

  // Create course mutation
  const createCourseMutation = useMutation({
    mutationFn: async (data: any) => {
      const courseData = {
        ...data,
        prerequisites: data.prerequisites ? data.prerequisites.split(",").map((p: string) => p.trim()) : [],
        features: data.features ? data.features.split(",").map((f: string) => f.trim()) : [],
      };
      await apiRequest("POST", "/api/courses", courseData);
    },
    onSuccess: () => {
      toast({
        title: "Course created",
        description: "Your course has been created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/institutes", institute?.id, "courses"] });
      setIsCreateCourseOpen(false);
      courseForm.reset();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create course",
        variant: "destructive",
      });
    },
  });

  const onInstituteSubmit = (data: any) => {
    createInstituteMutation.mutate(data);
  };

  const onCourseSubmit = (data: any) => {
    createCourseMutation.mutate(data);
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-main-bg flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary-blue" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return null; // Will redirect via useEffect
  }

  // If no institute profile exists, show creation form
  if (!instituteLoading && !institute) {
    return (
      <div className="min-h-screen bg-main-bg">
        <Navigation />
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <Card>
            <CardHeader>
              <CardTitle className="text-center text-accent-orange">Setup Your Institute Profile</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={instituteForm.handleSubmit(onInstituteSubmit)} className="space-y-4">
                <div>
                  <Label htmlFor="name">Institute Name</Label>
                  <Input
                    id="name"
                    {...instituteForm.register("name")}
                    placeholder="Your Institute Name"
                  />
                  {instituteForm.formState.errors.name && (
                    <p className="text-sm text-red-600 mt-1">
                      {instituteForm.formState.errors.name.message}
                    </p>
                  )}
                </div>

                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    {...instituteForm.register("description")}
                    placeholder="Tell students about your institute..."
                    rows={4}
                  />
                  {instituteForm.formState.errors.description && (
                    <p className="text-sm text-red-600 mt-1">
                      {instituteForm.formState.errors.description.message}
                    </p>
                  )}
                </div>

                <div>
                  <Label htmlFor="location">Location</Label>
                  <Input
                    id="location"
                    {...instituteForm.register("location")}
                    placeholder="City, Country"
                  />
                  {instituteForm.formState.errors.location && (
                    <p className="text-sm text-red-600 mt-1">
                      {instituteForm.formState.errors.location.message}
                    </p>
                  )}
                </div>

                <div>
                  <Label htmlFor="website">Website (Optional)</Label>
                  <Input
                    id="website"
                    {...instituteForm.register("website")}
                    placeholder="https://your-website.com"
                  />
                  {instituteForm.formState.errors.website && (
                    <p className="text-sm text-red-600 mt-1">
                      {instituteForm.formState.errors.website.message}
                    </p>
                  )}
                </div>

                <div>
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    {...instituteForm.register("phone")}
                    placeholder="+1 234 567 8900"
                  />
                  {instituteForm.formState.errors.phone && (
                    <p className="text-sm text-red-600 mt-1">
                      {instituteForm.formState.errors.phone.message}
                    </p>
                  )}
                </div>

                <Button
                  type="submit"
                  className="w-full bg-accent-orange hover:bg-orange-600 text-white"
                  disabled={createInstituteMutation.isPending}
                >
                  {createInstituteMutation.isPending ? "Creating..." : "Create Institute Profile"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-main-bg">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-text-primary mb-2">
            Institute Dashboard
          </h1>
          <p className="text-gray-600">
            Manage your courses and track your institute's performance
          </p>
        </div>

        <Tabs defaultValue="analytics" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              <span className="hidden sm:inline">Analytics</span>
            </TabsTrigger>
            <TabsTrigger value="create-course" className="flex items-center gap-2">
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">Create Course</span>
            </TabsTrigger>
            <TabsTrigger value="manage-courses" className="flex items-center gap-2">
              <BookOpen className="w-4 h-4" />
              <span className="hidden sm:inline">Manage Courses</span>
            </TabsTrigger>
            <TabsTrigger value="profile" className="flex items-center gap-2">
              <Edit className="w-4 h-4" />
              <span className="hidden sm:inline">Profile</span>
            </TabsTrigger>
          </TabsList>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            {/* Analytics Overview */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card className="bg-secondary-bg">
                <CardContent className="p-6 text-center">
                  <div className="text-2xl font-bold text-primary-blue">
                    {analyticsLoading ? <Loader2 className="w-6 h-6 animate-spin mx-auto" /> : (analytics?.totalViews || 0)}
                  </div>
                  <div className="text-sm text-gray-600">Total Views</div>
                </CardContent>
              </Card>
              
              <Card className="bg-secondary-bg">
                <CardContent className="p-6 text-center">
                  <div className="text-2xl font-bold text-accent-orange">
                    {analyticsLoading ? <Loader2 className="w-6 h-6 animate-spin mx-auto" /> : (analytics?.totalBookmarks || 0)}
                  </div>
                  <div className="text-sm text-gray-600">Bookmarks</div>
                </CardContent>
              </Card>
              
              <Card className="bg-secondary-bg">
                <CardContent className="p-6 text-center">
                  <div className="text-2xl font-bold text-success-green">
                    {analyticsLoading ? <Loader2 className="w-6 h-6 animate-spin mx-auto" /> : (analytics?.totalApplications || 0)}
                  </div>
                  <div className="text-sm text-gray-600">Applications</div>
                </CardContent>
              </Card>
              
              <Card className="bg-secondary-bg">
                <CardContent className="p-6 text-center">
                  <div className="text-2xl font-bold text-text-primary">
                    {coursesLoading ? <Loader2 className="w-6 h-6 animate-spin mx-auto" /> : courses.length}
                  </div>
                  <div className="text-sm text-gray-600">Active Courses</div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Applications */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Applications</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <Users className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-600 mb-2">No recent applications</h3>
                  <p className="text-gray-500">Applications will appear here when students apply to your courses</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Create Course Tab */}
          <TabsContent value="create-course" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Create New Course</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={courseForm.handleSubmit(onCourseSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="course-title">Course Title</Label>
                      <Input
                        id="course-title"
                        {...courseForm.register("title")}
                        placeholder="e.g., Complete Web Development Bootcamp"
                      />
                      {courseForm.formState.errors.title && (
                        <p className="text-sm text-red-600 mt-1">
                          {courseForm.formState.errors.title.message}
                        </p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="course-subject">Subject</Label>
                      <Input
                        id="course-subject"
                        {...courseForm.register("subject")}
                        placeholder="e.g., Web Development"
                      />
                      {courseForm.formState.errors.subject && (
                        <p className="text-sm text-red-600 mt-1">
                          {courseForm.formState.errors.subject.message}
                        </p>
                      )}
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="course-short-description">Short Description</Label>
                    <Input
                      id="course-short-description"
                      {...courseForm.register("shortDescription")}
                      placeholder="Brief one-line description"
                    />
                    {courseForm.formState.errors.shortDescription && (
                      <p className="text-sm text-red-600 mt-1">
                        {courseForm.formState.errors.shortDescription.message}
                      </p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="course-description">Full Description</Label>
                    <Textarea
                      id="course-description"
                      {...courseForm.register("description")}
                      placeholder="Detailed course description..."
                      rows={4}
                    />
                    {courseForm.formState.errors.description && (
                      <p className="text-sm text-red-600 mt-1">
                        {courseForm.formState.errors.description.message}
                      </p>
                    )}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="course-price">Price</Label>
                      <Input
                        id="course-price"
                        {...courseForm.register("price")}
                        placeholder="₹24,999"
                      />
                      {courseForm.formState.errors.price && (
                        <p className="text-sm text-red-600 mt-1">
                          {courseForm.formState.errors.price.message}
                        </p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="course-duration">Duration</Label>
                      <Input
                        id="course-duration"
                        {...courseForm.register("duration")}
                        placeholder="12 weeks"
                      />
                      {courseForm.formState.errors.duration && (
                        <p className="text-sm text-red-600 mt-1">
                          {courseForm.formState.errors.duration.message}
                        </p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="course-type">Course Type</Label>
                      <Select onValueChange={(value) => courseForm.setValue("courseType", value as any)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="online">Online</SelectItem>
                          <SelectItem value="offline">Offline</SelectItem>
                          <SelectItem value="hybrid">Hybrid</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="prerequisites">Prerequisites (comma-separated)</Label>
                    <Input
                      id="prerequisites"
                      {...courseForm.register("prerequisites")}
                      placeholder="Basic Computer Skills, JavaScript, React"
                    />
                  </div>

                  <div>
                    <Label htmlFor="features">Features (comma-separated)</Label>
                    <Input
                      id="features"
                      {...courseForm.register("features")}
                      placeholder="Certificate Provided, Live Projects, Mentor Support"
                    />
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-accent-orange hover:bg-orange-600 text-white"
                    disabled={createCourseMutation.isPending}
                  >
                    {createCourseMutation.isPending ? "Creating..." : "Create Course"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Manage Courses Tab */}
          <TabsContent value="manage-courses" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Your Courses</CardTitle>
              </CardHeader>
              <CardContent>
                {coursesLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin text-primary-blue" />
                  </div>
                ) : courses.length > 0 ? (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Course Title</TableHead>
                          <TableHead>Subject</TableHead>
                          <TableHead>Price</TableHead>
                          <TableHead>Duration</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {courses.map((course: any) => (
                          <TableRow key={course.id}>
                            <TableCell className="font-medium">{course.title}</TableCell>
                            <TableCell>{course.subject}</TableCell>
                            <TableCell>{course.price}</TableCell>
                            <TableCell>{course.duration}</TableCell>
                            <TableCell className="capitalize">{course.courseType}</TableCell>
                            <TableCell>
                              <Badge className={course.isActive ? "bg-success-green text-white" : "bg-gray-500 text-white"}>
                                {course.isActive ? "Active" : "Inactive"}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex space-x-2">
                                <Button size="sm" variant="outline">
                                  <Edit className="w-4 h-4" />
                                </Button>
                                <Button size="sm" variant="outline">
                                  <Eye className="w-4 h-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <BookOpen className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-600 mb-2">No courses yet</h3>
                    <p className="text-gray-500 mb-4">Create your first course to get started</p>
                    <Button 
                      className="bg-accent-orange hover:bg-orange-600 text-white"
                      onClick={() => {/* Switch to create course tab */}}
                    >
                      Create Course
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Profile Tab */}
          <TabsContent value="profile" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Institute Profile</CardTitle>
              </CardHeader>
              <CardContent>
                {instituteLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin text-primary-blue" />
                  </div>
                ) : institute ? (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label>Institute Name</Label>
                        <div className="px-3 py-2 border rounded bg-gray-50">{institute.name}</div>
                      </div>
                      <div>
                        <Label>Location</Label>
                        <div className="px-3 py-2 border rounded bg-gray-50">{institute.location}</div>
                      </div>
                    </div>
                    
                    <div>
                      <Label>Description</Label>
                      <div className="px-3 py-2 border rounded bg-gray-50 min-h-20">{institute.description}</div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label>Website</Label>
                        <div className="px-3 py-2 border rounded bg-gray-50">{institute.website || "Not provided"}</div>
                      </div>
                      <div>
                        <Label>Phone</Label>
                        <div className="px-3 py-2 border rounded bg-gray-50">{institute.phone}</div>
                      </div>
                    </div>

                    <div className="pt-4">
                      <Button variant="outline">Edit Profile</Button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-500">Institute profile not found</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
