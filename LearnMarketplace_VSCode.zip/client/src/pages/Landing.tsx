import Navigation from "@/components/Navigation";
import HeroSection from "@/components/HeroSection";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BookOpen, Users, Award, TrendingUp } from "lucide-react";

export default function Landing() {
  const features = [
    {
      icon: <BookOpen className="w-8 h-8 text-primary-blue" />,
      title: "Diverse Courses",
      description: "Explore thousands of courses across technology, design, business, and more"
    },
    {
      icon: <Users className="w-8 h-8 text-primary-blue" />,
      title: "Expert Instructors",
      description: "Learn from industry professionals and certified instructors"
    },
    {
      icon: <Award className="w-8 h-8 text-primary-blue" />,
      title: "Certified Learning",
      description: "Earn certificates and credentials recognized by employers"
    },
    {
      icon: <TrendingUp className="w-8 h-8 text-primary-blue" />,
      title: "Career Growth",
      description: "Advance your career with skills that matter in today's market"
    }
  ];

  return (
    <div className="min-h-screen bg-main-bg">
      <Navigation />
      <HeroSection />
      
      {/* Features Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-text-primary mb-4">
              Why Choose EduMarket?
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Join thousands of learners who have transformed their careers through our platform
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="bg-card-bg text-center">
                <CardContent className="p-6">
                  <div className="flex justify-center mb-4">
                    {feature.icon}
                  </div>
                  <h3 className="text-lg font-semibold text-text-primary mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-secondary-bg py-16">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-text-primary mb-4">
            Ready to Start Learning?
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Join our community of learners and take the first step towards your goals
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button 
              className="bg-primary-blue hover:bg-blue-600 text-white px-8 py-3 text-lg"
              onClick={() => window.location.href = "/api/login"}
            >
              Get Started as Student
            </Button>
            <Button 
              className="bg-accent-orange hover:bg-orange-600 text-white px-8 py-3 text-lg"
              onClick={() => window.location.href = "/api/login"}
            >
              Join as Institute
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card-bg border-t py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center text-gray-600">
            <p>&copy; 2024 EduMarket. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
