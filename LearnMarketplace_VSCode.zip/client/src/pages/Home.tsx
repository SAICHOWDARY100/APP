import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Loader2 } from "lucide-react";
import Navigation from "@/components/Navigation";
import HeroSection from "@/components/HeroSection";
import FilterSidebar from "@/components/FilterSidebar";
import CourseCard from "@/components/CourseCard";
import ComparisonTray from "@/components/ComparisonTray";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { SearchFilters, ComparisonItem, CourseWithInstitute } from "@/lib/types";
import { mockCourses } from "@/lib/mockData";

export default function Home() {
  const [location] = useLocation();
  const [filters, setFilters] = useState<SearchFilters>({
    subject: [],
    courseType: '',
    duration: [],
  });
  const [sortBy, setSortBy] = useState("popular");
  const [comparisonItems, setComparisonItems] = useState<ComparisonItem[]>([]);
  const [page, setPage] = useState(1);

  // Extract search query from URL
  const searchParams = new URLSearchParams(location.split('?')[1] || '');
  const searchQuery = searchParams.get('search') || '';

  const { data: courses = [], isLoading, error } = useQuery({
    queryKey: ["/api/courses", searchQuery, filters, sortBy],
    queryFn: async () => {
      const params = new URLSearchParams();
      
      if (searchQuery) params.append('search', searchQuery);
      if (filters.subject.length > 0) {
        filters.subject.forEach(s => params.append('subject', s));
      }
      if (filters.courseType) params.append('courseType', filters.courseType);
      if (filters.priceMin) params.append('priceMin', filters.priceMin.toString());
      if (filters.priceMax) params.append('priceMax', filters.priceMax.toString());

      const response = await fetch(`/api/courses?${params.toString()}`, {
        credentials: 'include'
      });
      
      if (!response.ok) {
        // Fallback to mock data if API fails
        return mockCourses;
      }
      
      return response.json();
    },
  });

  const handleFilterChange = (newFilters: SearchFilters) => {
    setFilters(newFilters);
    setPage(1);
  };

  const handleCompare = (course: CourseWithInstitute) => {
    const existingIndex = comparisonItems.findIndex(item => item.id === course.id);
    
    if (existingIndex >= 0) {
      // Remove from comparison
      setComparisonItems(comparisonItems.filter(item => item.id !== course.id));
    } else if (comparisonItems.length < 3) {
      // Add to comparison
      const comparisonItem: ComparisonItem = {
        id: course.id,
        type: 'course',
        title: course.title,
        institute: course.institute.name,
        price: course.price,
        rating: course.rating,
        duration: course.duration,
        courseType: course.courseType,
        features: course.features,
      };
      setComparisonItems([...comparisonItems, comparisonItem]);
    }
  };

  const handleRemoveFromComparison = (id: number) => {
    setComparisonItems(comparisonItems.filter(item => item.id !== id));
  };

  const handleClearComparison = () => {
    setComparisonItems([]);
  };

  const isInComparison = (courseId: number) => {
    return comparisonItems.some(item => item.id === courseId);
  };

  const sortOptions = [
    { value: "popular", label: "Most Popular" },
    { value: "rating", label: "Highest Rated" },
    { value: "price-low", label: "Price: Low to High" },
    { value: "price-high", label: "Price: High to Low" },
    { value: "newest", label: "Newest First" },
  ];

  return (
    <div className="min-h-screen bg-main-bg">
      <Navigation />
      <HeroSection />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filter Sidebar */}
          <aside className="w-full lg:w-80">
            <FilterSidebar
              filters={filters}
              onFiltersChange={handleFilterChange}
            />
          </aside>

          {/* Main Content */}
          <main className="flex-1" id="courses">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
              <div>
                <h2 className="text-2xl font-bold text-text-primary">
                  {searchQuery ? `Search Results for "${searchQuery}"` : "Featured Courses"}
                </h2>
                <p className="text-gray-600 mt-1">
                  {courses.length} course{courses.length !== 1 ? 's' : ''} found
                </p>
              </div>
              
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-full sm:w-48">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  {sortOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Loading State */}
            {isLoading && (
              <div className="flex justify-center items-center py-12">
                <Loader2 className="w-8 h-8 animate-spin text-primary-blue" />
                <span className="ml-2 text-gray-600">Loading courses...</span>
              </div>
            )}

            {/* Error State */}
            {error && (
              <div className="text-center py-12">
                <p className="text-red-600 mb-4">Failed to load courses. Showing sample courses instead.</p>
              </div>
            )}

            {/* Course Grid */}
            {!isLoading && courses.length > 0 && (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 mb-8">
                  {courses.slice(0, page * 6).map((course: CourseWithInstitute) => (
                    <CourseCard
                      key={course.id}
                      course={course}
                      onCompare={handleCompare}
                      isInComparison={isInComparison(course.id)}
                    />
                  ))}
                </div>

                {/* Load More Button */}
                {courses.length > page * 6 && (
                  <div className="text-center">
                    <Button
                      onClick={() => setPage(page + 1)}
                      className="bg-primary-blue hover:bg-blue-600 text-white px-8 py-3"
                    >
                      Load More Courses
                    </Button>
                  </div>
                )}
              </>
            )}

            {/* Empty State */}
            {!isLoading && courses.length === 0 && (
              <div className="text-center py-12">
                <h3 className="text-xl font-semibold text-gray-600 mb-2">No courses found</h3>
                <p className="text-gray-500 mb-4">
                  Try adjusting your search criteria or filters
                </p>
                <Button
                  onClick={() => handleFilterChange({
                    subject: [],
                    courseType: '',
                    duration: [],
                  })}
                  variant="outline"
                >
                  Clear Filters
                </Button>
              </div>
            )}
          </main>
        </div>
      </main>

      {/* Comparison Tray */}
      <ComparisonTray
        items={comparisonItems}
        onRemove={handleRemoveFromComparison}
        onClear={handleClearComparison}
      />
    </div>
  );
}
