import { useState } from "react";
import { useRoute } from "wouter";
import { MapPin, Globe, Phone, Star, Users, BookOpen, Heart, Loader2, ArrowLeft } from "lucide-react";
import Navigation from "@/components/Navigation";
import CourseCard from "@/components/CourseCard";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Link } from "wouter";
import { CourseWithInstitute } from "@/lib/types";

export default function InstituteProfile() {
  const [, params] = useRoute("/institutes/:id");
  const instituteId = params?.id;
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch institute details
  const { data: institute, isLoading: instituteLoading, error: instituteError } = useQuery({
    queryKey: ["/api/institutes", instituteId],
    enabled: !!instituteId,
    retry: false,
  });

  // Fetch institute courses
  const { data: courses = [], isLoading: coursesLoading } = useQuery({
    queryKey: ["/api/institutes", instituteId, "courses"],
    enabled: !!instituteId,
    retry: false,
  });

  // Fetch institute reviews
  const { data: reviews = [], isLoading: reviewsLoading } = useQuery({
    queryKey: ["/api/institutes", instituteId, "reviews"],
    enabled: !!instituteId,
    retry: false,
  });

  // Check if following
  const { data: followStatus } = useQuery({
    queryKey: ["/api/institutes", instituteId, "follow-status"],
    enabled: isAuthenticated && !!instituteId,
    retry: false,
  });

  const isFollowing = followStatus?.isFollowing || false;

  // Follow/unfollow mutation
  const followMutation = useMutation({
    mutationFn: async () => {
      if (isFollowing) {
        await apiRequest("DELETE", `/api/institutes/${instituteId}/follow`);
      } else {
        await apiRequest("POST", `/api/institutes/${instituteId}/follow`);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/institutes", instituteId, "follow-status"] });
      toast({
        title: isFollowing ? "Unfollowed institute" : "Following institute",
        description: isFollowing 
          ? "You will no longer receive updates from this institute" 
          : "You will receive notifications about new courses",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update follow status",
        variant: "destructive",
      });
    },
  });

  const handleFollow = () => {
    if (!isAuthenticated) {
      toast({
        title: "Login required",
        description: "Please login to follow institutes",
        variant: "destructive",
      });
      return;
    }
    followMutation.mutate();
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-4 h-4 ${
          i < Math.floor(rating) 
            ? "text-success-green fill-success-green" 
            : i < rating 
              ? "text-success-green fill-success-green/50" 
              : "text-gray-300"
        }`}
      />
    ));
  };

  if (instituteLoading) {
    return (
      <div className="min-h-screen bg-main-bg">
        <Navigation />
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 animate-spin text-primary-blue" />
          <span className="ml-2 text-gray-600">Loading institute profile...</span>
        </div>
      </div>
    );
  }

  if (instituteError || !institute) {
    return (
      <div className="min-h-screen bg-main-bg">
        <Navigation />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <Card>
            <CardContent className="p-8 text-center">
              <h1 className="text-2xl font-bold text-gray-600 mb-4">Institute Not Found</h1>
              <p className="text-gray-500 mb-6">The institute you're looking for doesn't exist or has been removed.</p>
              <Link href="/">
                <Button className="bg-primary-blue hover:bg-blue-600 text-white">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Courses
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const averageRating = reviews.length > 0 
    ? reviews.reduce((sum: number, review: any) => sum + review.rating, 0) / reviews.length 
    : 0;

  return (
    <div className="min-h-screen bg-main-bg">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back Button */}
        <div className="mb-6">
          <Link href="/">
            <Button variant="outline" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Courses
            </Button>
          </Link>
        </div>

        {/* Institute Header */}
        <Card className="mb-8">
          <CardContent className="p-8">
            <div className="flex flex-col md:flex-row gap-6 items-start">
              {/* Institute Logo */}
              <div className="w-24 h-24 bg-primary-blue rounded-lg flex items-center justify-center text-white text-2xl font-bold">
                {institute.logo ? (
                  <img 
                    src={institute.logo} 
                    alt={`${institute.name} logo`}
                    className="w-full h-full object-cover rounded-lg"
                  />
                ) : (
                  institute.name.charAt(0).toUpperCase()
                )}
              </div>

              {/* Institute Info */}
              <div className="flex-1">
                <div className="flex flex-col md:flex-row md:items-start md:justify-between mb-4">
                  <div>
                    <div className="flex items-center gap-3 mb-2">
                      <h1 className="text-3xl font-bold text-text-primary">
                        {institute.name}
                      </h1>
                      {institute.isVerified && (
                        <Badge className="bg-success-green text-white">
                          Verified
                        </Badge>
                      )}
                    </div>
                    
                    {/* Rating */}
                    <div className="flex items-center mb-3">
                      <div className="flex mr-2">
                        {renderStars(averageRating)}
                      </div>
                      <span className="text-sm text-gray-600">
                        {averageRating.toFixed(1)} ({reviews.length} reviews)
                      </span>
                    </div>

                    {/* Location */}
                    {institute.location && (
                      <div className="flex items-center text-gray-600 mb-2">
                        <MapPin className="w-4 h-4 mr-2" />
                        <span>{institute.location}</span>
                      </div>
                    )}
                  </div>

                  {/* Follow Button */}
                  <Button
                    onClick={handleFollow}
                    disabled={followMutation.isPending}
                    className={isFollowing 
                      ? "bg-gray-500 hover:bg-gray-600 text-white" 
                      : "bg-primary-blue hover:bg-blue-600 text-white"
                    }
                  >
                    <Heart className={`w-4 h-4 mr-2 ${isFollowing ? "fill-current" : ""}`} />
                    {isFollowing ? "Following" : "Follow Institute"}
                  </Button>
                </div>

                {/* Contact Info */}
                <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                  {institute.website && (
                    <a 
                      href={institute.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center hover:text-primary-blue"
                    >
                      <Globe className="w-4 h-4 mr-1" />
                      Website
                    </a>
                  )}
                  {institute.phone && (
                    <a 
                      href={`tel:${institute.phone}`}
                      className="flex items-center hover:text-primary-blue"
                    >
                      <Phone className="w-4 h-4 mr-1" />
                      {institute.phone}
                    </a>
                  )}
                  <span className="flex items-center">
                    <BookOpen className="w-4 h-4 mr-1" />
                    {courses.length} Courses
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* About Section */}
            <Card>
              <CardHeader>
                <CardTitle>About {institute.name}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 leading-relaxed">
                  {institute.description || "No description available."}
                </p>
              </CardContent>
            </Card>

            {/* Courses Section */}
            <Card>
              <CardHeader>
                <CardTitle>Offered Courses</CardTitle>
              </CardHeader>
              <CardContent>
                {coursesLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin text-primary-blue" />
                  </div>
                ) : courses.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {courses.map((course: CourseWithInstitute) => (
                      <div key={course.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                        <img
                          src={course.thumbnail || "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200"}
                          alt={course.title}
                          className="w-full h-32 object-cover rounded mb-3"
                        />
                        <h3 className="font-semibold mb-2">{course.title}</h3>
                        <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                          {course.shortDescription}
                        </p>
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-text-primary">{course.price}</span>
                          <Link href={`/courses/${course.id}`}>
                            <Button size="sm" variant="outline">
                              View Details
                            </Button>
                          </Link>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <BookOpen className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-600 mb-2">No courses available</h3>
                    <p className="text-gray-500">This institute hasn't published any courses yet</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Reviews Section */}
            <Card>
              <CardHeader>
                <CardTitle>Reviews</CardTitle>
              </CardHeader>
              <CardContent>
                {reviewsLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin text-primary-blue" />
                  </div>
                ) : reviews.length > 0 ? (
                  <div className="space-y-6">
                    {reviews.map((review: any) => (
                      <div key={review.id} className="border-b border-gray-200 pb-6 last:border-b-0">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center">
                            <div className="flex mr-2">
                              {renderStars(review.rating)}
                            </div>
                            <span className="text-sm text-gray-600">
                              {new Date(review.createdAt).toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                        {review.comment && (
                          <p className="text-gray-700">{review.comment}</p>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Star className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-600 mb-2">No reviews yet</h3>
                    <p className="text-gray-500">Be the first to review this institute</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Stats */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Total Courses</span>
                  <span className="font-semibold">{courses.length}</span>
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Average Rating</span>
                  <span className="font-semibold">{averageRating.toFixed(1)}</span>
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Total Reviews</span>
                  <span className="font-semibold">{reviews.length}</span>
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Verified Institute</span>
                  <Badge className={institute.isVerified ? "bg-success-green text-white" : "bg-gray-500 text-white"}>
                    {institute.isVerified ? "Yes" : "No"}
                  </Badge>
                </div>
              </CardContent>
            </Card>

            {/* Contact Card */}
            <Card>
              <CardHeader>
                <CardTitle>Get In Touch</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {institute.website && (
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    onClick={() => window.open(institute.website, '_blank')}
                  >
                    <Globe className="w-4 h-4 mr-2" />
                    Visit Website
                  </Button>
                )}
                
                {institute.phone && (
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    onClick={() => window.open(`tel:${institute.phone}`, '_self')}
                  >
                    <Phone className="w-4 h-4 mr-2" />
                    Call Institute
                  </Button>
                )}

                <Button
                  onClick={handleFollow}
                  disabled={followMutation.isPending}
                  className={`w-full ${isFollowing 
                    ? "bg-gray-500 hover:bg-gray-600" 
                    : "bg-primary-blue hover:bg-blue-600"
                  } text-white`}
                >
                  <Heart className={`w-4 h-4 mr-2 ${isFollowing ? "fill-current" : ""}`} />
                  {isFollowing ? "Following" : "Follow for Updates"}
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
