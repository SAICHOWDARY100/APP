import { useState } from "react";
import { Link, useLocation } from "wouter";
import { User, Building, Shield, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import SearchBar from "./SearchBar";

export default function Navigation() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [location] = useLocation();
  const { user, isAuthenticated } = useAuth();

  const navItems = [
    { href: "/", label: "Browse Courses", active: location === "/" },
    { href: "/institutes", label: "Institutes", active: location === "/institutes" },
    { href: "/about", label: "About", active: location === "/about" },
  ];

  const getDashboardPath = () => {
    if (!user) return "/";
    switch (user.role) {
      case "student": return "/dashboard/student";
      case "institute": return "/dashboard/institute";
      case "admin": return "/dashboard/admin";
      default: return "/";
    }
  };

  return (
    <nav className="bg-card-bg shadow-md sticky top-0 z-50" role="navigation" aria-label="Main navigation">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center space-x-8">
            <div className="flex-shrink-0">
              <Link href="/">
                <h1 className="text-2xl font-bold text-primary-blue cursor-pointer">EduMarket</h1>
              </Link>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                {navItems.map((item) => (
                  <Link key={item.href} href={item.href}>
                    <a className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      item.active 
                        ? "text-primary-blue bg-secondary-bg" 
                        : "text-text-primary hover:text-primary-blue"
                    }`}>
                      {item.label}
                    </a>
                  </Link>
                ))}
              </div>
            </div>
          </div>
          
          {/* Search Bar */}
          <div className="flex-1 max-w-2xl mx-8 hidden sm:block">
            <SearchBar />
          </div>

          {/* Auth Buttons */}
          <div className="flex items-center space-x-4">
            {isAuthenticated ? (
              <div className="flex items-center space-x-2">
                <Link href={getDashboardPath()}>
                  <Button variant="outline" size="sm" className="hidden lg:flex">
                    {user?.role === "student" && <User className="w-4 h-4 mr-2" />}
                    {user?.role === "institute" && <Building className="w-4 h-4 mr-2" />}
                    {user?.role === "admin" && <Shield className="w-4 h-4 mr-2" />}
                    Dashboard
                  </Button>
                </Link>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => window.location.href = "/api/logout"}
                  className="hidden lg:flex"
                >
                  Logout
                </Button>
              </div>
            ) : (
              <div className="hidden lg:flex items-center space-x-2">
                <Button 
                  className="bg-primary-blue hover:bg-blue-600 text-white"
                  size="sm"
                  onClick={() => window.location.href = "/api/login"}
                >
                  <User className="w-4 h-4 mr-2" />
                  Student Login
                </Button>
                <Button 
                  className="bg-accent-orange hover:bg-orange-600 text-white"
                  size="sm"
                  onClick={() => window.location.href = "/api/login"}
                >
                  <Building className="w-4 h-4 mr-2" />
                  Institute Login
                </Button>
              </div>
            )}
            
            {/* Mobile menu button */}
            <Button
              variant="ghost"
              size="sm"
              className="md:hidden"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              aria-label="Toggle mobile menu"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Search */}
        <div className="sm:hidden pb-4">
          <SearchBar />
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden border-t border-gray-200 bg-card-bg">
          <div className="px-2 pt-2 pb-3 space-y-1">
            {navItems.map((item) => (
              <Link key={item.href} href={item.href}>
                <a 
                  className={`block px-3 py-2 rounded-md text-base font-medium ${
                    item.active 
                      ? "text-primary-blue bg-secondary-bg" 
                      : "text-text-primary hover:text-primary-blue hover:bg-gray-50"
                  }`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {item.label}
                </a>
              </Link>
            ))}
            
            {/* Mobile Auth Buttons */}
            <div className="pt-4 space-y-2">
              {isAuthenticated ? (
                <>
                  <Link href={getDashboardPath()}>
                    <Button 
                      variant="outline" 
                      className="w-full justify-start"
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      {user?.role === "student" && <User className="w-4 h-4 mr-2" />}
                      {user?.role === "institute" && <Building className="w-4 h-4 mr-2" />}
                      {user?.role === "admin" && <Shield className="w-4 h-4 mr-2" />}
                      Dashboard
                    </Button>
                  </Link>
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    onClick={() => window.location.href = "/api/logout"}
                  >
                    Logout
                  </Button>
                </>
              ) : (
                <>
                  <Button 
                    className="w-full bg-primary-blue hover:bg-blue-600 text-white justify-start"
                    onClick={() => window.location.href = "/api/login"}
                  >
                    <User className="w-4 h-4 mr-2" />
                    Student Login
                  </Button>
                  <Button 
                    className="w-full bg-accent-orange hover:bg-orange-600 text-white justify-start"
                    onClick={() => window.location.href = "/api/login"}
                  >
                    <Building className="w-4 h-4 mr-2" />
                    Institute Login
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
