import { useState, useEffect } from "react";
import { MapPin, Filter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { SearchFilters } from "@/lib/types";
import { mockSubjects } from "@/lib/mockData";

interface FilterSidebarProps {
  filters: SearchFilters;
  onFiltersChange: (filters: SearchFilters) => void;
  className?: string;
}

export default function FilterSidebar({ filters, onFiltersChange, className = "" }: FilterSidebarProps) {
  const [localFilters, setLocalFilters] = useState<SearchFilters>(filters);
  const [priceRange, setPriceRange] = useState([0, 50000]);

  useEffect(() => {
    setLocalFilters(filters);
    setPriceRange([filters.priceMin || 0, filters.priceMax || 50000]);
  }, [filters]);

  const updateFilters = (updates: Partial<SearchFilters>) => {
    const newFilters = { ...localFilters, ...updates };
    setLocalFilters(newFilters);
  };

  const applyFilters = () => {
    const filtersToApply = {
      ...localFilters,
      priceMin: priceRange[0] > 0 ? priceRange[0] : undefined,
      priceMax: priceRange[1] < 50000 ? priceRange[1] : undefined,
    };
    onFiltersChange(filtersToApply);
  };

  const clearFilters = () => {
    const clearedFilters: SearchFilters = {
      subject: [],
      courseType: '',
      priceMin: undefined,
      priceMax: undefined,
      rating: undefined,
      duration: [],
      location: undefined,
    };
    setLocalFilters(clearedFilters);
    setPriceRange([0, 50000]);
    onFiltersChange(clearedFilters);
  };

  const handleSubjectChange = (subject: string, checked: boolean) => {
    const newSubjects = checked
      ? [...localFilters.subject, subject]
      : localFilters.subject.filter(s => s !== subject);
    updateFilters({ subject: newSubjects });
  };

  const handleDurationChange = (duration: string, checked: boolean) => {
    const newDurations = checked
      ? [...localFilters.duration, duration]
      : localFilters.duration.filter(d => d !== duration);
    updateFilters({ duration: newDurations });
  };

  const durations = ["< 1 month", "1-3 months", "3-6 months", "6+ months"];

  return (
    <Card className={`w-full lg:w-80 bg-secondary-bg ${className}`}>
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center text-xl font-semibold text-text-primary">
          <Filter className="w-5 h-5 mr-2" />
          Filter Courses
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Location Filter */}
        <div>
          <Label htmlFor="location-filter" className="text-sm font-medium text-text-primary mb-2 block">
            Location
          </Label>
          <div className="relative">
            <Input
              id="location-filter"
              type="text"
              value={localFilters.location || ""}
              onChange={(e) => updateFilters({ location: e.target.value })}
              placeholder="Enter city or country..."
              className="pl-10"
            />
            <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          </div>
        </div>

        {/* Price Range Filter */}
        <div>
          <Label className="text-sm font-medium text-text-primary mb-2 block">
            Price Range
          </Label>
          <div className="px-2">
            <Slider
              value={priceRange}
              onValueChange={setPriceRange}
              max={50000}
              step={1000}
              className="w-full"
              aria-label="Price range slider"
            />
            <div className="flex justify-between text-sm text-gray-600 mt-2">
              <span>₹{priceRange[0].toLocaleString()}</span>
              <span>₹{priceRange[1].toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Rating Filter */}
        <div>
          <Label className="text-sm font-medium text-text-primary mb-2 block">
            Minimum Rating
          </Label>
          <RadioGroup
            value={localFilters.rating?.toString() || ""}
            onValueChange={(value) => updateFilters({ rating: value ? parseInt(value) : undefined })}
          >
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="4" id="rating-4" />
                <Label htmlFor="rating-4" className="flex items-center cursor-pointer">
                  <div className="flex text-success-green mr-2">
                    {Array.from({ length: 4 }, (_, i) => (
                      <span key={i}>★</span>
                    ))}
                    <span className="text-gray-300">★</span>
                  </div>
                  <span className="text-sm">4.0 & above</span>
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="3" id="rating-3" />
                <Label htmlFor="rating-3" className="flex items-center cursor-pointer">
                  <div className="flex text-success-green mr-2">
                    {Array.from({ length: 3 }, (_, i) => (
                      <span key={i}>★</span>
                    ))}
                    {Array.from({ length: 2 }, (_, i) => (
                      <span key={i} className="text-gray-300">★</span>
                    ))}
                  </div>
                  <span className="text-sm">3.0 & above</span>
                </Label>
              </div>
            </div>
          </RadioGroup>
        </div>

        {/* Course Type Filter */}
        <div>
          <Label className="text-sm font-medium text-text-primary mb-2 block">
            Course Type
          </Label>
          <div className="flex bg-gray-200 rounded-lg p-1">
            <Button
              variant={localFilters.courseType === "online" ? "default" : "ghost"}
              size="sm"
              className={`flex-1 ${
                localFilters.courseType === "online" 
                  ? "bg-primary-blue text-white" 
                  : "text-gray-700 hover:bg-gray-300"
              }`}
              onClick={() => updateFilters({ 
                courseType: localFilters.courseType === "online" ? "" : "online" 
              })}
            >
              Online
            </Button>
            <Button
              variant={localFilters.courseType === "offline" ? "default" : "ghost"}
              size="sm"
              className={`flex-1 ${
                localFilters.courseType === "offline" 
                  ? "bg-primary-blue text-white" 
                  : "text-gray-700 hover:bg-gray-300"
              }`}
              onClick={() => updateFilters({ 
                courseType: localFilters.courseType === "offline" ? "" : "offline" 
              })}
            >
              Offline
            </Button>
          </div>
        </div>

        {/* Duration Filter */}
        <div>
          <Label className="text-sm font-medium text-text-primary mb-2 block">
            Duration
          </Label>
          <div className="flex flex-wrap gap-2">
            {durations.map((duration) => (
              <Badge
                key={duration}
                variant={localFilters.duration.includes(duration) ? "default" : "outline"}
                className={`cursor-pointer ${
                  localFilters.duration.includes(duration)
                    ? "bg-primary-blue text-white"
                    : "bg-gray-200 text-gray-700 hover:bg-gray-300"
                }`}
                onClick={() => handleDurationChange(duration, !localFilters.duration.includes(duration))}
              >
                {duration}
              </Badge>
            ))}
          </div>
        </div>

        {/* Subject Filter */}
        <div>
          <Label className="text-sm font-medium text-text-primary mb-2 block">
            Subject
          </Label>
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {mockSubjects.map((subject) => (
              <div key={subject} className="flex items-center space-x-2">
                <Checkbox
                  id={`subject-${subject}`}
                  checked={localFilters.subject.includes(subject)}
                  onCheckedChange={(checked) => handleSubjectChange(subject, checked as boolean)}
                />
                <Label
                  htmlFor={`subject-${subject}`}
                  className="text-sm cursor-pointer"
                >
                  {subject}
                </Label>
              </div>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2 pt-4 border-t">
          <Button
            onClick={applyFilters}
            className="w-full bg-accent-orange hover:bg-orange-600 text-white"
          >
            Apply Filters
          </Button>
          <Button
            onClick={clearFilters}
            variant="outline"
            className="w-full"
          >
            Clear All
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
