import { X, BarChart3 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ComparisonItem } from "@/lib/types";
import { Link } from "wouter";

interface ComparisonTrayProps {
  items: ComparisonItem[];
  onRemove: (id: number) => void;
  onClear: () => void;
}

export default function ComparisonTray({ items, onRemove, onClear }: ComparisonTrayProps) {
  if (items.length === 0) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-card-bg border-t-2 border-primary-blue shadow-lg p-4 z-40 transform transition-transform duration-300">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <BarChart3 className="text-primary-blue w-6 h-6" />
          <div className="flex items-center space-x-2">
            <span className="font-medium text-text-primary">
              Compare {items.length === 1 ? "Course" : "Courses"} ({items.length} selected)
            </span>
            {items.length > 1 && (
              <div className="flex space-x-1">
                {items.slice(0, 3).map((item) => (
                  <Badge key={item.id} variant="outline" className="text-xs">
                    {item.title.length > 20 ? `${item.title.substring(0, 20)}...` : item.title}
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-auto p-0 ml-1 hover:bg-transparent"
                      onClick={() => onRemove(item.id)}
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </Badge>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center space-x-2">
          {items.length >= 2 && (
            <Link href="/comparison">
              <Button className="bg-primary-blue hover:bg-blue-600 text-white">
                View Comparison
              </Button>
            </Link>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={onClear}
            className="text-gray-500 hover:text-gray-700"
            aria-label="Clear comparison"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
