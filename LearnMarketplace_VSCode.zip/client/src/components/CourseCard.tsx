import { useState } from "react";
import { Heart, Clock, Laptop, Users, Star, BarChart3 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { CourseWithInstitute } from "@/lib/types";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";

interface CourseCardProps {
  course: CourseWithInstitute;
  onCompare?: (course: CourseWithInstitute) => void;
  isInComparison?: boolean;
  showInstitute?: boolean;
}

export default function CourseCard({ 
  course, 
  onCompare, 
  isInComparison = false,
  showInstitute = true 
}: CourseCardProps) {
  const [isBookmarked, setIsBookmarked] = useState(course.isBookmarked || false);
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const bookmarkMutation = useMutation({
    mutationFn: async () => {
      if (isBookmarked) {
        await apiRequest("DELETE", `/api/bookmarks/${course.id}`);
      } else {
        await apiRequest("POST", "/api/bookmarks", { courseId: course.id });
      }
    },
    onSuccess: () => {
      setIsBookmarked(!isBookmarked);
      queryClient.invalidateQueries({ queryKey: ["/api/bookmarks"] });
      toast({
        title: isBookmarked ? "Bookmark removed" : "Course bookmarked",
        description: isBookmarked 
          ? "Course removed from your saved list" 
          : "Course added to your saved list",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update bookmark",
        variant: "destructive",
      });
    },
  });

  const applyMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/applications", { courseId: course.id });
    },
    onSuccess: () => {
      toast({
        title: "Application submitted",
        description: "Your application has been submitted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/applications"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to submit application",
        variant: "destructive",
      });
    },
  });

  const handleBookmark = () => {
    if (!isAuthenticated) {
      toast({
        title: "Login required",
        description: "Please login to bookmark courses",
        variant: "destructive",
      });
      return;
    }
    bookmarkMutation.mutate();
  };

  const handleApply = () => {
    if (!isAuthenticated) {
      toast({
        title: "Login required", 
        description: "Please login to apply for courses",
        variant: "destructive",
      });
      return;
    }
    applyMutation.mutate();
  };

  const handleCompare = () => {
    if (onCompare) {
      onCompare(course);
    }
  };

  const getCourseTypeIcon = () => {
    switch (course.courseType) {
      case "online": return <Laptop className="w-4 h-4" />;
      case "offline": return <Users className="w-4 h-4" />;
      case "hybrid": return <Users className="w-4 h-4" />;
      default: return <Laptop className="w-4 h-4" />;
    }
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-4 h-4 ${
          i < Math.floor(rating) 
            ? "text-success-green fill-success-green" 
            : i < rating 
              ? "text-success-green fill-success-green/50" 
              : "text-gray-300"
        }`}
      />
    ));
  };

  return (
    <Card className="bg-card-bg hover:shadow-lg transition-shadow duration-300">
      <div className="relative">
        <img
          src={course.thumbnail}
          alt={`${course.title} course thumbnail`}
          className="w-full h-48 object-cover rounded-t-lg"
        />
        {showInstitute && (
          <div className="absolute top-4 left-4">
            <Badge variant="secondary" className="bg-white/90 text-primary-blue">
              {course.institute.name}
            </Badge>
          </div>
        )}
        <Button
          variant="ghost"
          size="sm"
          className={`absolute top-4 right-4 ${
            isBookmarked ? "text-accent-orange" : "text-gray-400 hover:text-accent-orange"
          }`}
          onClick={handleBookmark}
          disabled={bookmarkMutation.isPending}
          aria-label={isBookmarked ? "Remove from bookmarks" : "Add to bookmarks"}
        >
          <Heart className={`w-5 h-5 ${isBookmarked ? "fill-current" : ""}`} />
        </Button>
      </div>

      <CardContent className="p-6">
        <h3 className="text-lg font-semibold text-text-primary mb-2 line-clamp-2">
          {course.title}
        </h3>
        
        <p className="text-gray-600 text-sm mb-4 line-clamp-3">
          {course.shortDescription}
        </p>

        {/* Rating */}
        {course.rating && (
          <div className="flex items-center mb-4">
            <div className="flex mr-2" aria-label={`${course.rating} out of 5 stars`}>
              {renderStars(course.rating)}
            </div>
            <span className="text-sm text-gray-600">
              {course.rating} ({course.reviewCount} reviews)
            </span>
          </div>
        )}

        {/* Course Info */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-4 text-sm text-gray-600">
            <span className="flex items-center">
              <Clock className="w-4 h-4 mr-1" />
              {course.duration}
            </span>
            <span className="flex items-center">
              {getCourseTypeIcon()}
              <span className="ml-1 capitalize">{course.courseType}</span>
            </span>
          </div>
          <div className="text-right">
            <span className="text-lg font-bold text-text-primary">{course.price}</span>
          </div>
        </div>

        {/* Prerequisites */}
        {course.prerequisites && course.prerequisites.length > 0 && (
          <div className="flex items-center mb-4">
            <span className="text-xs text-gray-500 mr-2">Prerequisites:</span>
            <div className="flex flex-wrap gap-1">
              {course.prerequisites.slice(0, 2).map((prereq, index) => (
                <Badge key={index} variant="outline" className="text-xs">
                  {prereq}
                </Badge>
              ))}
              {course.prerequisites.length > 2 && (
                <Badge variant="outline" className="text-xs">
                  +{course.prerequisites.length - 2} more
                </Badge>
              )}
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex space-x-2">
          <Button 
            className="flex-1 bg-accent-orange hover:bg-orange-600 text-white"
            onClick={handleApply}
            disabled={applyMutation.isPending}
          >
            {applyMutation.isPending ? "Applying..." : "Apply Now"}
          </Button>
          
          {onCompare && (
            <Button
              variant="outline"
              size="icon"
              onClick={handleCompare}
              className={isInComparison ? "border-primary-blue text-primary-blue border-2" : ""}
              aria-label={isInComparison ? "Remove from comparison" : "Add to comparison"}
            >
              <BarChart3 className="w-4 h-4" />
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
