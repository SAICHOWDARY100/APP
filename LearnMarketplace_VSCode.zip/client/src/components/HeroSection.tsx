import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { Link } from "wouter";

export default function HeroSection() {
  const { isAuthenticated } = useAuth();

  return (
    <section className="bg-secondary-bg py-12" aria-labelledby="hero-heading">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 id="hero-heading" className="text-4xl font-bold text-text-primary mb-4">
            Discover Your Next Learning Journey
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Connect with top educational institutes and find courses that match your goals. 
            From data science to design, start learning today.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link href="/#courses">
              <Button className="bg-primary-blue hover:bg-blue-600 text-white px-8 py-3 text-lg">
                Browse Courses
              </Button>
            </Link>
            {!isAuthenticated ? (
              <Button
                variant="outline"
                className="border-2 border-primary-blue text-primary-blue hover:bg-secondary-bg px-8 py-3 text-lg"
                onClick={() => window.location.href = "/api/login"}
              >
                For Institutes
              </Button>
            ) : (
              <Link href="/dashboard/institute">
                <Button
                  variant="outline" 
                  className="border-2 border-primary-blue text-primary-blue hover:bg-secondary-bg px-8 py-3 text-lg"
                >
                  Institute Dashboard
                </Button>
              </Link>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
