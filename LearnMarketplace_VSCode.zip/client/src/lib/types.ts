export interface SearchFilters {
  subject: string[];
  courseType: 'online' | 'offline' | 'hybrid' | '';
  priceMin?: number;
  priceMax?: number;
  rating?: number;
  duration: string[];
  location?: string;
}

export interface ComparisonItem {
  id: number;
  type: 'course' | 'institute';
  title: string;
  institute?: string;
  price?: string;
  rating?: number;
  duration?: string;
  courseType?: string;
  features?: string[];
}

export interface CourseWithInstitute {
  id: number;
  title: string;
  description: string;
  shortDescription: string;
  thumbnail: string;
  price: string;
  duration: string;
  courseType: 'online' | 'offline' | 'hybrid';
  subject: string;
  prerequisites: string[];
  features: string[];
  isActive: boolean;
  institute: {
    id: number;
    name: string;
    logo?: string;
  };
  rating?: number;
  reviewCount?: number;
  isBookmarked?: boolean;
}

export interface InstituteWithCourses {
  id: number;
  name: string;
  description: string;
  logo?: string;
  location?: string;
  website?: string;
  phone?: string;
  isVerified: boolean;
  courses: CourseWithInstitute[];
  rating?: number;
  reviewCount?: number;
  isFollowed?: boolean;
}

export interface UserProfile {
  id: string;
  email: string;
  firstName?: string;
  lastName?: string;
  profileImageUrl?: string;
  role: 'student' | 'institute' | 'admin';
}

export interface DashboardStats {
  totalViews?: number;
  totalBookmarks?: number;
  totalApplications?: number;
  totalCourses?: number;
  flaggedReviews?: number;
  pendingDisputes?: number;
  totalUsers?: number;
}
