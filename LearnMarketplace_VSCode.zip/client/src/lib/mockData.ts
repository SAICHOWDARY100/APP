import { CourseWithInstitute, InstituteWithCourses } from './types';

export const mockCourses: CourseWithInstitute[] = [
  {
    id: 1,
    title: "Complete Web Development Bootcamp",
    description: "Learn HTML, CSS, JavaScript, React, and Node.js from scratch. Build real-world projects and become a full-stack developer.",
    shortDescription: "Learn HTML, CSS, JavaScript, React, and Node.js from scratch. Build real-world projects and become a full-stack developer.",
    thumbnail: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=200",
    price: "₹24,999",
    duration: "12 weeks",
    courseType: "online",
    subject: "Web Development",
    prerequisites: ["Basic Computer Skills"],
    features: ["Certificate Provided", "Live Projects", "Mentor Support"],
    isActive: true,
    institute: {
      id: 1,
      name: "TechEd Institute",
      logo: undefined
    },
    rating: 4.8,
    reviewCount: 1234,
    isBookmarked: false
  },
  {
    id: 2,
    title: "Data Science & Machine Learning",
    description: "Master Python, statistics, machine learning algorithms, and data visualization. Work on real business problems.",
    shortDescription: "Master Python, statistics, machine learning algorithms, and data visualization. Work on real business problems.",
    thumbnail: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=200",
    price: "₹34,999",
    duration: "16 weeks",
    courseType: "online",
    subject: "Data Science",
    prerequisites: ["Basic Math", "Programming"],
    features: ["Certificate Provided", "Industry Projects", "Job Assistance"],
    isActive: true,
    institute: {
      id: 2,
      name: "DataPro Academy",
      logo: undefined
    },
    rating: 4.9,
    reviewCount: 856,
    isBookmarked: true
  },
  {
    id: 3,
    title: "UI/UX Design Mastery",
    description: "Learn user research, wireframing, prototyping, and visual design. Master Figma, Adobe XD, and design thinking.",
    shortDescription: "Learn user research, wireframing, prototyping, and visual design. Master Figma, Adobe XD, and design thinking.",
    thumbnail: "https://images.unsplash.com/photo-1559028006-448665bd7c7f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=200",
    price: "₹19,999",
    duration: "10 weeks",
    courseType: "hybrid",
    subject: "UI/UX Design",
    prerequisites: ["Creative Interest"],
    features: ["Portfolio Projects", "Tool Access", "Design Critique"],
    isActive: true,
    institute: {
      id: 3,
      name: "Design Studio Pro",
      logo: undefined
    },
    rating: 4.7,
    reviewCount: 623,
    isBookmarked: false
  },
  {
    id: 4,
    title: "Digital Marketing Specialist",
    description: "Learn SEO, social media marketing, Google Ads, content marketing, and analytics. Get industry certifications.",
    shortDescription: "Learn SEO, social media marketing, Google Ads, content marketing, and analytics. Get industry certifications.",
    thumbnail: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=200",
    price: "₹14,999",
    duration: "8 weeks",
    courseType: "online",
    subject: "Digital Marketing",
    prerequisites: ["Basic Computer"],
    features: ["Industry Certifications", "Live Campaigns", "Analytics Tools"],
    isActive: true,
    institute: {
      id: 4,
      name: "Marketing Hub",
      logo: undefined
    },
    rating: 4.6,
    reviewCount: 934,
    isBookmarked: false
  },
  {
    id: 5,
    title: "React Native App Development",
    description: "Build cross-platform mobile apps using React Native. Learn navigation, state management, and app store deployment.",
    shortDescription: "Build cross-platform mobile apps using React Native. Learn navigation, state management, and app store deployment.",
    thumbnail: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=200",
    price: "₹29,999",
    duration: "14 weeks",
    courseType: "online",
    subject: "Mobile Development",
    prerequisites: ["JavaScript", "React"],
    features: ["App Store Deployment", "Real Apps", "Code Reviews"],
    isActive: true,
    institute: {
      id: 5,
      name: "Mobile Dev Institute",
      logo: undefined
    },
    rating: 4.5,
    reviewCount: 412,
    isBookmarked: false
  },
  {
    id: 6,
    title: "AWS Cloud Architect",
    description: "Master AWS services, cloud architecture patterns, security, and cost optimization. Prepare for AWS certifications.",
    shortDescription: "Master AWS services, cloud architecture patterns, security, and cost optimization. Prepare for AWS certifications.",
    thumbnail: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=200",
    price: "₹39,999",
    duration: "20 weeks",
    courseType: "online",
    subject: "Cloud Computing",
    prerequisites: ["Linux", "Networking"],
    features: ["AWS Certification", "Hands-on Labs", "Industry Projects"],
    isActive: true,
    institute: {
      id: 6,
      name: "CloudTech Academy",
      logo: undefined
    },
    rating: 4.8,
    reviewCount: 567,
    isBookmarked: false
  }
];

export const mockInstitutes: InstituteWithCourses[] = [
  {
    id: 1,
    name: "TechEd Institute",
    description: "Leading technology education provider with industry-expert instructors and hands-on curriculum.",
    location: "Bangalore, India",
    website: "https://teched.edu",
    phone: "+91 98765 43210",
    isVerified: true,
    courses: mockCourses.filter(course => course.institute.id === 1),
    rating: 4.8,
    reviewCount: 2341,
    isFollowed: false
  },
  {
    id: 2,
    name: "DataPro Academy",
    description: "Specialized in data science and analytics education with real-world projects and industry partnerships.",
    location: "Mumbai, India",
    website: "https://datapro.edu",
    phone: "+91 98765 43211",
    isVerified: true,
    courses: mockCourses.filter(course => course.institute.id === 2),
    rating: 4.9,
    reviewCount: 1856,
    isFollowed: true
  }
];

export const mockSubjects = [
  "Data Science",
  "Web Development", 
  "Mobile Development",
  "UI/UX Design",
  "Digital Marketing",
  "Cloud Computing",
  "Artificial Intelligence",
  "Cybersecurity",
  "DevOps",
  "Blockchain"
];

export const mockSearchSuggestions = [
  "Data Science Fundamentals",
  "React Native Development",
  "Machine Learning Bootcamp",
  "UI/UX Design Course",
  "Digital Marketing Specialist",
  "AWS Cloud Architecture",
  "Python Programming",
  "JavaScript Full Stack"
];
