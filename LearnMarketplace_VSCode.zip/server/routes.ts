import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import {
  insertInstituteSchema,
  insertCourseSchema,
  insertReviewSchema,
  insertBookmarkSchema,
  insertApplicationSchema,
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Course routes
  app.get('/api/courses', async (req, res) => {
    try {
      const { search, subject, courseType, priceMin, priceMax } = req.query;
      const filters = {
        subject: subject ? (Array.isArray(subject) ? subject : [subject]) : [],
        courseType: courseType as string,
        priceMin: priceMin ? parseFloat(priceMin as string) : undefined,
        priceMax: priceMax ? parseFloat(priceMax as string) : undefined,
      };
      
      const courses = search 
        ? await storage.searchCourses(search as string, filters)
        : await storage.getFeaturedCourses();
      
      res.json(courses);
    } catch (error) {
      console.error("Error fetching courses:", error);
      res.status(500).json({ message: "Failed to fetch courses" });
    }
  });

  app.get('/api/courses/:id', async (req, res) => {
    try {
      const course = await storage.getCourse(parseInt(req.params.id));
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      res.json(course);
    } catch (error) {
      console.error("Error fetching course:", error);
      res.status(500).json({ message: "Failed to fetch course" });
    }
  });

  app.post('/api/courses', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const institute = await storage.getInstituteByUserId(userId);
      
      if (!institute) {
        return res.status(403).json({ message: "Only institutes can create courses" });
      }

      const courseData = insertCourseSchema.parse({
        ...req.body,
        instituteId: institute.id,
      });
      
      const course = await storage.createCourse(courseData);
      res.status(201).json(course);
    } catch (error) {
      console.error("Error creating course:", error);
      res.status(500).json({ message: "Failed to create course" });
    }
  });

  // Institute routes
  app.get('/api/institutes', async (req, res) => {
    try {
      const institutes = await storage.getInstitutes();
      res.json(institutes);
    } catch (error) {
      console.error("Error fetching institutes:", error);
      res.status(500).json({ message: "Failed to fetch institutes" });
    }
  });

  app.get('/api/institutes/:id', async (req, res) => {
    try {
      const institute = await storage.getInstitute(parseInt(req.params.id));
      if (!institute) {
        return res.status(404).json({ message: "Institute not found" });
      }
      res.json(institute);
    } catch (error) {
      console.error("Error fetching institute:", error);
      res.status(500).json({ message: "Failed to fetch institute" });
    }
  });

  app.get('/api/institutes/:id/courses', async (req, res) => {
    try {
      const courses = await storage.getCoursesByInstitute(parseInt(req.params.id));
      res.json(courses);
    } catch (error) {
      console.error("Error fetching institute courses:", error);
      res.status(500).json({ message: "Failed to fetch institute courses" });
    }
  });

  app.post('/api/institutes', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const instituteData = insertInstituteSchema.parse({
        ...req.body,
        userId,
      });
      
      const institute = await storage.createInstitute(instituteData);
      res.status(201).json(institute);
    } catch (error) {
      console.error("Error creating institute:", error);
      res.status(500).json({ message: "Failed to create institute" });
    }
  });

  app.get('/api/my-institute', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const institute = await storage.getInstituteByUserId(userId);
      res.json(institute);
    } catch (error) {
      console.error("Error fetching user institute:", error);
      res.status(500).json({ message: "Failed to fetch institute" });
    }
  });

  // Bookmark routes
  app.get('/api/bookmarks', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const bookmarks = await storage.getBookmarksByUser(userId);
      res.json(bookmarks);
    } catch (error) {
      console.error("Error fetching bookmarks:", error);
      res.status(500).json({ message: "Failed to fetch bookmarks" });
    }
  });

  app.post('/api/bookmarks', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const bookmarkData = insertBookmarkSchema.parse({
        ...req.body,
        userId,
      });
      
      const bookmark = await storage.createBookmark(bookmarkData);
      res.status(201).json(bookmark);
    } catch (error) {
      console.error("Error creating bookmark:", error);
      res.status(500).json({ message: "Failed to create bookmark" });
    }
  });

  app.delete('/api/bookmarks/:courseId', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const courseId = parseInt(req.params.courseId);
      
      await storage.removeBookmark(userId, courseId);
      res.status(204).send();
    } catch (error) {
      console.error("Error removing bookmark:", error);
      res.status(500).json({ message: "Failed to remove bookmark" });
    }
  });

  app.get('/api/bookmarks/:courseId/check', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const courseId = parseInt(req.params.courseId);
      
      const isBookmarked = await storage.isBookmarked(userId, courseId);
      res.json({ isBookmarked });
    } catch (error) {
      console.error("Error checking bookmark:", error);
      res.status(500).json({ message: "Failed to check bookmark" });
    }
  });

  // Application routes
  app.get('/api/applications', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const applications = await storage.getApplicationsByUser(userId);
      res.json(applications);
    } catch (error) {
      console.error("Error fetching applications:", error);
      res.status(500).json({ message: "Failed to fetch applications" });
    }
  });

  app.post('/api/applications', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const applicationData = insertApplicationSchema.parse({
        ...req.body,
        userId,
      });
      
      const application = await storage.createApplication(applicationData);
      res.status(201).json(application);
    } catch (error) {
      console.error("Error creating application:", error);
      res.status(500).json({ message: "Failed to create application" });
    }
  });

  app.patch('/api/applications/:id/status', isAuthenticated, async (req: any, res) => {
    try {
      const { status } = req.body;
      const applicationId = parseInt(req.params.id);
      
      const application = await storage.updateApplicationStatus(applicationId, status);
      res.json(application);
    } catch (error) {
      console.error("Error updating application status:", error);
      res.status(500).json({ message: "Failed to update application status" });
    }
  });

  // Review routes
  app.get('/api/courses/:id/reviews', async (req, res) => {
    try {
      const courseId = parseInt(req.params.id);
      const reviews = await storage.getReviewsByCourse(courseId);
      res.json(reviews);
    } catch (error) {
      console.error("Error fetching course reviews:", error);
      res.status(500).json({ message: "Failed to fetch reviews" });
    }
  });

  app.post('/api/reviews', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const reviewData = insertReviewSchema.parse({
        ...req.body,
        userId,
      });
      
      const review = await storage.createReview(reviewData);
      res.status(201).json(review);
    } catch (error) {
      console.error("Error creating review:", error);
      res.status(500).json({ message: "Failed to create review" });
    }
  });

  // Institute follow routes
  app.post('/api/institutes/:id/follow', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const instituteId = parseInt(req.params.id);
      
      await storage.followInstitute(userId, instituteId);
      res.status(201).json({ message: "Institute followed successfully" });
    } catch (error) {
      console.error("Error following institute:", error);
      res.status(500).json({ message: "Failed to follow institute" });
    }
  });

  app.delete('/api/institutes/:id/follow', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const instituteId = parseInt(req.params.id);
      
      await storage.unfollowInstitute(userId, instituteId);
      res.status(204).send();
    } catch (error) {
      console.error("Error unfollowing institute:", error);
      res.status(500).json({ message: "Failed to unfollow institute" });
    }
  });

  // Analytics routes
  app.get('/api/analytics/institute/:id', isAuthenticated, async (req: any, res) => {
    try {
      const instituteId = parseInt(req.params.id);
      const analytics = await storage.getInstituteAnalytics(instituteId);
      res.json(analytics);
    } catch (error) {
      console.error("Error fetching institute analytics:", error);
      res.status(500).json({ message: "Failed to fetch analytics" });
    }
  });

  app.get('/api/analytics/admin', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const metrics = await storage.getAdminMetrics();
      res.json(metrics);
    } catch (error) {
      console.error("Error fetching admin metrics:", error);
      res.status(500).json({ message: "Failed to fetch metrics" });
    }
  });

  // Admin routes
  app.get('/api/admin/flagged-reviews', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const flaggedReviews = await storage.getFlaggedReviews();
      res.json(flaggedReviews);
    } catch (error) {
      console.error("Error fetching flagged reviews:", error);
      res.status(500).json({ message: "Failed to fetch flagged reviews" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
