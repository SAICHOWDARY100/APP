import {
  users,
  institutes,
  courses,
  reviews,
  bookmarks,
  applications,
  instituteFollows,
  type User,
  type UpsertUser,
  type Institute,
  type InsertInstitute,
  type Course,
  type InsertCourse,
  type Review,
  type InsertReview,
  type Bookmark,
  type InsertBookmark,
  type Application,
  type InsertApplication,
  type InsertInstituteFollow,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, like, or, sql, inArray } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Institute operations
  getInstitute(id: number): Promise<Institute | undefined>;
  getInstituteByUserId(userId: string): Promise<Institute | undefined>;
  createInstitute(institute: InsertInstitute): Promise<Institute>;
  updateInstitute(id: number, institute: Partial<InsertInstitute>): Promise<Institute>;
  getInstitutes(): Promise<Institute[]>;
  
  // Course operations
  getCourse(id: number): Promise<Course | undefined>;
  getCoursesByInstitute(instituteId: number): Promise<Course[]>;
  createCourse(course: InsertCourse): Promise<Course>;
  updateCourse(id: number, course: Partial<InsertCourse>): Promise<Course>;
  searchCourses(query: string, filters?: any): Promise<Course[]>;
  getFeaturedCourses(): Promise<Course[]>;
  
  // Review operations
  getReviewsByCourse(courseId: number): Promise<Review[]>;
  getReviewsByInstitute(instituteId: number): Promise<Review[]>;
  createReview(review: InsertReview): Promise<Review>;
  updateReview(id: number, review: Partial<InsertReview>): Promise<Review>;
  flagReview(id: number): Promise<Review>;
  getFlaggedReviews(): Promise<Review[]>;
  
  // Bookmark operations
  getBookmarksByUser(userId: string): Promise<Bookmark[]>;
  createBookmark(bookmark: InsertBookmark): Promise<Bookmark>;
  removeBookmark(userId: string, courseId: number): Promise<void>;
  isBookmarked(userId: string, courseId: number): Promise<boolean>;
  
  // Application operations
  getApplicationsByUser(userId: string): Promise<Application[]>;
  getApplicationsByCourse(courseId: number): Promise<Application[]>;
  createApplication(application: InsertApplication): Promise<Application>;
  updateApplicationStatus(id: number, status: string): Promise<Application>;
  
  // Institute follow operations
  followInstitute(userId: string, instituteId: number): Promise<void>;
  unfollowInstitute(userId: string, instituteId: number): Promise<void>;
  getFollowedInstitutes(userId: string): Promise<number[]>;
  
  // Analytics
  getInstituteAnalytics(instituteId: number): Promise<any>;
  getAdminMetrics(): Promise<any>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Institute operations
  async getInstitute(id: number): Promise<Institute | undefined> {
    const [institute] = await db.select().from(institutes).where(eq(institutes.id, id));
    return institute;
  }

  async getInstituteByUserId(userId: string): Promise<Institute | undefined> {
    const [institute] = await db.select().from(institutes).where(eq(institutes.userId, userId));
    return institute;
  }

  async createInstitute(institute: InsertInstitute): Promise<Institute> {
    const [newInstitute] = await db.insert(institutes).values(institute).returning();
    return newInstitute;
  }

  async updateInstitute(id: number, institute: Partial<InsertInstitute>): Promise<Institute> {
    const [updated] = await db
      .update(institutes)
      .set({ ...institute, updatedAt: new Date() })
      .where(eq(institutes.id, id))
      .returning();
    return updated;
  }

  async getInstitutes(): Promise<Institute[]> {
    return db.select().from(institutes).where(eq(institutes.isActive, true));
  }

  // Course operations
  async getCourse(id: number): Promise<Course | undefined> {
    const [course] = await db.select().from(courses).where(eq(courses.id, id));
    return course;
  }

  async getCoursesByInstitute(instituteId: number): Promise<Course[]> {
    return db.select().from(courses).where(eq(courses.instituteId, instituteId));
  }

  async createCourse(course: InsertCourse): Promise<Course> {
    const [newCourse] = await db.insert(courses).values(course).returning();
    return newCourse;
  }

  async updateCourse(id: number, course: Partial<InsertCourse>): Promise<Course> {
    const [updated] = await db
      .update(courses)
      .set({ ...course, updatedAt: new Date() })
      .where(eq(courses.id, id))
      .returning();
    return updated;
  }

  async searchCourses(query: string, filters?: any): Promise<Course[]> {
    let queryBuilder = db.select().from(courses).where(eq(courses.isActive, true));
    
    if (query) {
      queryBuilder = queryBuilder.where(
        or(
          like(courses.title, `%${query}%`),
          like(courses.description, `%${query}%`),
          like(courses.subject, `%${query}%`)
        )
      );
    }

    if (filters?.subject?.length > 0) {
      queryBuilder = queryBuilder.where(inArray(courses.subject, filters.subject));
    }

    if (filters?.courseType) {
      queryBuilder = queryBuilder.where(eq(courses.courseType, filters.courseType));
    }

    if (filters?.priceMin || filters?.priceMax) {
      if (filters.priceMin) {
        queryBuilder = queryBuilder.where(sql`${courses.price} >= ${filters.priceMin}`);
      }
      if (filters.priceMax) {
        queryBuilder = queryBuilder.where(sql`${courses.price} <= ${filters.priceMax}`);
      }
    }

    return queryBuilder.orderBy(desc(courses.createdAt));
  }

  async getFeaturedCourses(): Promise<Course[]> {
    return db.select()
      .from(courses)
      .where(eq(courses.isActive, true))
      .orderBy(desc(courses.createdAt))
      .limit(12);
  }

  // Review operations
  async getReviewsByCourse(courseId: number): Promise<Review[]> {
    return db.select()
      .from(reviews)
      .where(and(eq(reviews.courseId, courseId), eq(reviews.isApproved, true)))
      .orderBy(desc(reviews.createdAt));
  }

  async getReviewsByInstitute(instituteId: number): Promise<Review[]> {
    return db.select()
      .from(reviews)
      .where(and(eq(reviews.instituteId, instituteId), eq(reviews.isApproved, true)))
      .orderBy(desc(reviews.createdAt));
  }

  async createReview(review: InsertReview): Promise<Review> {
    const [newReview] = await db.insert(reviews).values(review).returning();
    return newReview;
  }

  async updateReview(id: number, review: Partial<InsertReview>): Promise<Review> {
    const [updated] = await db
      .update(reviews)
      .set({ ...review, updatedAt: new Date() })
      .where(eq(reviews.id, id))
      .returning();
    return updated;
  }

  async flagReview(id: number): Promise<Review> {
    const [flagged] = await db
      .update(reviews)
      .set({ isFlagged: true, updatedAt: new Date() })
      .where(eq(reviews.id, id))
      .returning();
    return flagged;
  }

  async getFlaggedReviews(): Promise<Review[]> {
    return db.select().from(reviews).where(eq(reviews.isFlagged, true));
  }

  // Bookmark operations
  async getBookmarksByUser(userId: string): Promise<Bookmark[]> {
    return db.select().from(bookmarks).where(eq(bookmarks.userId, userId));
  }

  async createBookmark(bookmark: InsertBookmark): Promise<Bookmark> {
    const [newBookmark] = await db.insert(bookmarks).values(bookmark).returning();
    return newBookmark;
  }

  async removeBookmark(userId: string, courseId: number): Promise<void> {
    await db.delete(bookmarks)
      .where(and(eq(bookmarks.userId, userId), eq(bookmarks.courseId, courseId)));
  }

  async isBookmarked(userId: string, courseId: number): Promise<boolean> {
    const [bookmark] = await db.select()
      .from(bookmarks)
      .where(and(eq(bookmarks.userId, userId), eq(bookmarks.courseId, courseId)));
    return !!bookmark;
  }

  // Application operations
  async getApplicationsByUser(userId: string): Promise<Application[]> {
    return db.select().from(applications).where(eq(applications.userId, userId));
  }

  async getApplicationsByCourse(courseId: number): Promise<Application[]> {
    return db.select().from(applications).where(eq(applications.courseId, courseId));
  }

  async createApplication(application: InsertApplication): Promise<Application> {
    const [newApplication] = await db.insert(applications).values(application).returning();
    return newApplication;
  }

  async updateApplicationStatus(id: number, status: string): Promise<Application> {
    const [updated] = await db
      .update(applications)
      .set({ status, reviewedAt: new Date() })
      .where(eq(applications.id, id))
      .returning();
    return updated;
  }

  // Institute follow operations
  async followInstitute(userId: string, instituteId: number): Promise<void> {
    await db.insert(instituteFollows).values({ userId, instituteId });
  }

  async unfollowInstitute(userId: string, instituteId: number): Promise<void> {
    await db.delete(instituteFollows)
      .where(and(eq(instituteFollows.userId, userId), eq(instituteFollows.instituteId, instituteId)));
  }

  async getFollowedInstitutes(userId: string): Promise<number[]> {
    const follows = await db.select({ instituteId: instituteFollows.instituteId })
      .from(instituteFollows)
      .where(eq(instituteFollows.userId, userId));
    return follows.map(f => f.instituteId);
  }

  // Analytics
  async getInstituteAnalytics(instituteId: number): Promise<any> {
    const courseCount = await db.select({ count: sql<number>`count(*)` })
      .from(courses)
      .where(eq(courses.instituteId, instituteId));

    const applicationCount = await db.select({ count: sql<number>`count(*)` })
      .from(applications)
      .innerJoin(courses, eq(applications.courseId, courses.id))
      .where(eq(courses.instituteId, instituteId));

    const bookmarkCount = await db.select({ count: sql<number>`count(*)` })
      .from(bookmarks)
      .innerJoin(courses, eq(bookmarks.courseId, courses.id))
      .where(eq(courses.instituteId, instituteId));

    return {
      totalCourses: courseCount[0]?.count || 0,
      totalApplications: applicationCount[0]?.count || 0,
      totalBookmarks: bookmarkCount[0]?.count || 0,
      totalViews: Math.floor(Math.random() * 10000), // Mock data for views
    };
  }

  async getAdminMetrics(): Promise<any> {
    const userCount = await db.select({ count: sql<number>`count(*)` }).from(users);
    const courseCount = await db.select({ count: sql<number>`count(*)` }).from(courses);
    const flaggedReviewCount = await db.select({ count: sql<number>`count(*)` })
      .from(reviews)
      .where(eq(reviews.isFlagged, true));
    const pendingApplicationCount = await db.select({ count: sql<number>`count(*)` })
      .from(applications)
      .where(eq(applications.status, 'pending'));

    return {
      totalUsers: userCount[0]?.count || 0,
      totalCourses: courseCount[0]?.count || 0,
      flaggedReviews: flaggedReviewCount[0]?.count || 0,
      pendingDisputes: pendingApplicationCount[0]?.count || 0,
    };
  }
}

export const storage = new DatabaseStorage();
