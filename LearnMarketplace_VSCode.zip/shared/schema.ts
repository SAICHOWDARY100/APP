import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  decimal,
  boolean,
  pgEnum,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: varchar("role").notNull().default("student"), // student, institute, admin
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Institutes table
export const institutes = pgTable("institutes", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  name: varchar("name").notNull(),
  description: text("description"),
  logo: varchar("logo"),
  location: varchar("location"),
  website: varchar("website"),
  phone: varchar("phone"),
  isVerified: boolean("is_verified").default(false),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Course types enum
export const courseTypeEnum = pgEnum("course_type", ["online", "offline", "hybrid"]);

// Courses table
export const courses = pgTable("courses", {
  id: serial("id").primaryKey(),
  instituteId: integer("institute_id").notNull().references(() => institutes.id),
  title: varchar("title").notNull(),
  description: text("description"),
  shortDescription: varchar("short_description"),
  thumbnail: varchar("thumbnail"),
  price: decimal("price", { precision: 10, scale: 2 }),
  duration: varchar("duration"), // e.g., "12 weeks", "3 months"
  courseType: courseTypeEnum("course_type").default("online"),
  subject: varchar("subject"),
  prerequisites: text("prerequisites").array(),
  features: text("features").array(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Reviews table
export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  courseId: integer("course_id").references(() => courses.id),
  instituteId: integer("institute_id").references(() => institutes.id),
  rating: integer("rating").notNull(), // 1-5
  comment: text("comment"),
  isFlagged: boolean("is_flagged").default(false),
  isApproved: boolean("is_approved").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Bookmarks table
export const bookmarks = pgTable("bookmarks", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  courseId: integer("course_id").notNull().references(() => courses.id),
  createdAt: timestamp("created_at").defaultNow(),
});

// Applications table
export const applications = pgTable("applications", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  courseId: integer("course_id").notNull().references(() => courses.id),
  status: varchar("status").notNull().default("pending"), // pending, approved, rejected
  appliedAt: timestamp("applied_at").defaultNow(),
  reviewedAt: timestamp("reviewed_at"),
});

// Institute follows table
export const instituteFollows = pgTable("institute_follows", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  instituteId: integer("institute_id").notNull().references(() => institutes.id),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many, one }) => ({
  institute: one(institutes, {
    fields: [users.id],
    references: [institutes.userId],
  }),
  reviews: many(reviews),
  bookmarks: many(bookmarks),
  applications: many(applications),
  instituteFollows: many(instituteFollows),
}));

export const institutesRelations = relations(institutes, ({ one, many }) => ({
  user: one(users, {
    fields: [institutes.userId],
    references: [users.id],
  }),
  courses: many(courses),
  reviews: many(reviews),
  followers: many(instituteFollows),
}));

export const coursesRelations = relations(courses, ({ one, many }) => ({
  institute: one(institutes, {
    fields: [courses.instituteId],
    references: [institutes.id],
  }),
  reviews: many(reviews),
  bookmarks: many(bookmarks),
  applications: many(applications),
}));

export const reviewsRelations = relations(reviews, ({ one }) => ({
  user: one(users, {
    fields: [reviews.userId],
    references: [users.id],
  }),
  course: one(courses, {
    fields: [reviews.courseId],
    references: [courses.id],
  }),
  institute: one(institutes, {
    fields: [reviews.instituteId],
    references: [institutes.id],
  }),
}));

export const bookmarksRelations = relations(bookmarks, ({ one }) => ({
  user: one(users, {
    fields: [bookmarks.userId],
    references: [users.id],
  }),
  course: one(courses, {
    fields: [bookmarks.courseId],
    references: [courses.id],
  }),
}));

export const applicationsRelations = relations(applications, ({ one }) => ({
  user: one(users, {
    fields: [applications.userId],
    references: [users.id],
  }),
  course: one(courses, {
    fields: [applications.courseId],
    references: [courses.id],
  }),
}));

export const instituteFollowsRelations = relations(instituteFollows, ({ one }) => ({
  user: one(users, {
    fields: [instituteFollows.userId],
    references: [users.id],
  }),
  institute: one(institutes, {
    fields: [instituteFollows.instituteId],
    references: [institutes.id],
  }),
}));

// Insert schemas
export const upsertUserSchema = createInsertSchema(users);
export const insertInstituteSchema = createInsertSchema(institutes).omit({ id: true, createdAt: true, updatedAt: true });
export const insertCourseSchema = createInsertSchema(courses).omit({ id: true, createdAt: true, updatedAt: true });
export const insertReviewSchema = createInsertSchema(reviews).omit({ id: true, createdAt: true, updatedAt: true });
export const insertBookmarkSchema = createInsertSchema(bookmarks).omit({ id: true, createdAt: true });
export const insertApplicationSchema = createInsertSchema(applications).omit({ id: true, appliedAt: true, reviewedAt: true });
export const insertInstituteFollowSchema = createInsertSchema(instituteFollows).omit({ id: true, createdAt: true });

// Types
export type UpsertUser = z.infer<typeof upsertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertInstitute = z.infer<typeof insertInstituteSchema>;
export type Institute = typeof institutes.$inferSelect;
export type InsertCourse = z.infer<typeof insertCourseSchema>;
export type Course = typeof courses.$inferSelect;
export type InsertReview = z.infer<typeof insertReviewSchema>;
export type Review = typeof reviews.$inferSelect;
export type InsertBookmark = z.infer<typeof insertBookmarkSchema>;
export type Bookmark = typeof bookmarks.$inferSelect;
export type InsertApplication = z.infer<typeof insertApplicationSchema>;
export type Application = typeof applications.$inferSelect;
export type InsertInstituteFollow = z.infer<typeof insertInstituteFollowSchema>;
export type InstituteFollow = typeof instituteFollows.$inferSelect;
